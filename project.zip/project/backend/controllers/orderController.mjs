import Order from '../models/Order.mjs';
import Category from '../models/Category.mjs';
import mongoose from 'mongoose';
import OrderRequest from '../models/OrderRequest.mjs';
import User from '../models/User.mjs';
import { createNotification } from './notificationController.mjs';

// Вспомогательная функция для обновления счетчиков навыков
async function updateSkillCounters(categoryId, skills, action = 'add') {
  const category = await Category.findById(categoryId);
  if (!category) return;

  for (const skill of skills) {
    const skillCounter = category.skillCounts.find(s => s.name === skill);
    
    if (skillCounter) {
      skillCounter.orders += (action === 'add' ? 1 : -1);
      if (skillCounter.orders < 0) {
        skillCounter.orders = 0;
      }
    } else if (action === 'add') {
      category.skillCounts.push({ name: skill, orders: 1 });
    }
  }

  await category.save();
}

// Создание заявки на заказ
export const createOrderRequest = async (req, res) => {
  try {
    const { title, description, skills = [], category, price, daysLeft } = req.body;

    const errors = [];
    if (!title) errors.push('Не указано название');
    if (!description) errors.push('Не указано описание');
    if (!category) errors.push('Не указана категория');
    if (skills.length === 0) errors.push('Не указаны навыки');
    if (price === undefined || price === null) errors.push('Не указана цена');
    if (daysLeft === undefined || daysLeft === null) errors.push('Не указан срок выполнения');

    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Ошибки валидации',
        errors: errors
      });
    }

    if (isNaN(price)) errors.push('Цена должна быть числом');
    if (isNaN(daysLeft)) errors.push('Срок выполнения должен быть числом');
   
    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Ошибки валидации',
        errors: errors
      });
    }

    if (!req.user?._id) {
      return res.status(403).json({ 
        success: false,
        message: 'Доступ запрещен' 
      });
    }

    const categoryDoc = await Category.findById(category);
    if (!categoryDoc) {
      return res.status(404).json({ 
        success: false,
        message: 'Категория не найдена' 
      });
    }

    const orderRequest = new OrderRequest({
      title,
      description,
      skills,
      category,
      price: Number(price),
      daysLeft: Number(daysLeft),
      createdBy: req.user._id,
      status: 'pending'
    });

    await orderRequest.save();

    res.status(201).json({
      success: true,
      data: orderRequest
    });

  } catch (error) {
    console.error('Error creating order request:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при создании заявки на заказ',
      error: error.message
    });
  }
};

// Получение заявок (для админа)
export const getOrderRequests = async (req, res) => {
  try {
    const { status } = req.query;
    
    const query = {};
    if (status) {
      query.status = status;
    }

    const requests = await OrderRequest.find(query)
      .populate('createdBy', 'username email firstName lastName')
      .populate('category', 'title')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: requests
    });
  } catch (error) {
    console.error('Error getting order requests:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при получении заявок'
    });
  }
};

// Одобрение заявки (админ)
export const approveOrderRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const { adminComment } = req.body;

    const request = await OrderRequest.findById(id)
      .populate('createdBy', 'firstName lastName email')
      .populate('category', 'title services');

    if (!request) {
      return res.status(404).json({ 
        success: false,
        message: 'Заявка не найдена' 
      });
    }

    // Создаем заказ
    const order = new Order({
      title: request.title,
      description: request.description,
      skills: request.skills,
      price: request.price,
      daysLeft: request.daysLeft,
      createdBy: request.createdBy._id,
      category: request.category._id,
      status: 'active'
    });

    await order.save();

    // Обновляем счетчики навыков в категории
    await updateSkillCounters(request.category._id, request.skills, 'add');

    // Обновляем статус заявки
    await OrderRequest.findByIdAndUpdate(id, {
      status: 'approved',
      adminComment: adminComment || ''
    });

    res.status(200).json({
      success: true,
      data: {
        order: order,
        request: {
          ...request.toObject(),
          status: 'approved',
          adminComment: adminComment || ''
        }
      }
    });

  } catch (error) {
    console.error('Error approving order request:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при одобрении заявки',
      error: error.message
    });
  }
};

// Отклонение заявки (админ)
export const rejectOrderRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const { adminComment } = req.body;

    const request = await OrderRequest.findByIdAndUpdate(
      id,
      { 
        status: 'rejected',
        adminComment: adminComment || '' 
      },
      { new: true }
    );

    if (!request) {
      return res.status(404).json({ 
        success: false,
        message: 'Заявка не найдена' 
      });
    }

    res.status(200).json({
      success: true,
      data: request
    });
  } catch (error) {
    console.error('Error rejecting order request:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при отклонении заявки'
    });
  }
};

// Редактирование заявки (админ)
export const updateOrderRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, skills, category, price, daysLeft } = req.body;

    const request = await OrderRequest.findById(id);
    if (!request) {
      return res.status(404).json({ 
        success: false,
        message: 'Заявка не найдена' 
      });
    }

    request.title = title || request.title;
    request.description = description || request.description;
    request.skills = skills || request.skills;
    request.category = category || request.category;
    request.price = price || request.price;
    request.daysLeft = daysLeft || request.daysLeft;

    await request.save();

    res.status(200).json({
      success: true,
      data: request
    });
  } catch (error) {
    console.error('Error updating order request:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при обновлении заявки'
    });
  }
};

// Создание заказа (админ)
export const createOrder = async (req, res) => {
  try {
    const { title, daysLeft, description, skills = [], price, category } = req.body;

    if (!title || !daysLeft || !description || !price || !category || !skills.length) {
      return res.status(400).json({
        success: false,
        message: 'Все обязательные поля должны быть заполнены'
      });
    }

    if (skills.length > 5) {
      return res.status(400).json({
        success: false,
        message: 'Максимум 5 навыков в заказе'
      });
    }

    if (!req.user?._id) {
      return res.status(403).json({ 
        success: false,
        message: 'Доступ запрещен' 
      });
    }

    const categoryDoc = await Category.findById(category);
    if (!categoryDoc) {
      return res.status(404).json({ 
        success: false,
        message: 'Категория не найдена' 
      });
    }

    const order = new Order({
      title,
      daysLeft,
      description,
      skills,
      price,
      createdBy: req.user._id,
      category
    });

    await order.save();
    
    // Обновляем счетчики навыков в категории
    await updateSkillCounters(category, skills, 'add');

    res.status(201).json({
      success: true,
      data: order
    });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при создании заказа',
      error: error.message
    });
  }
};

// Получение заказов с фильтрацией
export const getOrders = async (req, res) => {
  try {
    const { page = 1, limit = 10, category, skill } = req.query;
    const skip = (page - 1) * limit;

    let query = {};
    
    if (category) {
      const categoryDoc = await Category.findOne({ link: category });
      if (!categoryDoc) {
        return res.status(404).json({ 
          success: false,
          message: 'Category not found'
        });
      }
      query.category = categoryDoc._id;
    }

    if (skill) {
      query.skills = skill;
    }

    const [total, orders] = await Promise.all([
      Order.countDocuments(query),
      Order.find(query)
        .skip(skip)
        .limit(parseInt(limit))
        .populate('createdBy', 'username email')
        .populate('category', 'title _id')
        .sort({ createdAt: -1 })
        .lean()
    ]);

    res.status(200).json({
      success: true,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(total / limit),
      orders
    });

  } catch (error) {
    console.error('Error in getOrders:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Получение заказов категории с пагинацией
export const getOrdersByCategory = async (req, res) => {
  try {
    const { categoryId } = req.params;
    const { page = 1, limit = 10 } = req.query;
    
    const skip = (page - 1) * limit;

    if (!mongoose.Types.ObjectId.isValid(categoryId)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Некорректный ID категории' 
      });
    }

    const category = await Category.findById(categoryId);
    if (!category) {
      return res.status(404).json({ 
        success: false, 
        message: 'Категория не найдена' 
      });
    }

    const [total, orders] = await Promise.all([
      Order.countDocuments({ category: categoryId }),
      Order.find({ category: categoryId })
        .skip(skip)
        .limit(parseInt(limit))
        .populate('createdBy', 'username email')
        .populate('category', 'title')
        .sort({ createdAt: -1 })
    ]);

    res.status(200).json({
      success: true,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(total / limit),
      orders,
      category: {
        title: category.title,
        icon: category.icon
      }
    });
  } catch (error) {
    console.error('Error in getOrdersByCategory:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Ошибка сервера',
      error: error.message 
    });
  }
};

// Получение заказа по ID
export const getOrderById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('createdBy', 'username email firstName lastName avatar createdAt') // Добавлено avatar и createdAt
      .populate('category', 'title icon')
      .populate('assignedTo', 'firstName lastName avatar rating');

    if (!order) {
      return res.status(404).json({ 
        success: false, 
        message: 'Заказ не найден' 
      });
    }

    res.json({ 
      success: true, 
      order 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Ошибка сервера',
      error: error.message 
    });
  }
};

// Обновление заказа (админ)
export const updateOrder = async (req, res) => {
  try {
    const { skills = [], category: newCategoryId } = req.body;
    const orderId = req.params.id;

    if (skills.length > 5) {
      return res.status(400).json({
        success: false,
        message: 'Максимум 5 навыков в заказе'
      });
    }

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ 
        success: false,
        message: 'Заказ не найден' 
      });
    }

    const oldCategoryId = order.category;
    const categoryChanged = newCategoryId && newCategoryId !== oldCategoryId;

    // Уменьшаем счетчики в старой категории
    if (oldCategoryId && order.skills.length) {
      await updateSkillCounters(oldCategoryId, order.skills, 'remove');
    }

    // Обновляем данные заказа
    Object.assign(order, {
      title: req.body.title || order.title,
      daysLeft: req.body.daysLeft || order.daysLeft,
      description: req.body.description || order.description,
      skills,
      price: req.body.price || order.price,
      category: newCategoryId || order.category
    });

    await order.save();

    // Увеличиваем счетчики в новой категории
    const targetCategoryId = categoryChanged ? newCategoryId : oldCategoryId;
    if (targetCategoryId && skills.length) {
      await updateSkillCounters(targetCategoryId, skills, 'add');
    }

    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    console.error('Error updating order:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при обновлении заказа'
    });
  }
};

// Удаление заказа (админ)
export const deleteOrder = async (req, res) => {
  try {
    const order = await Order.findByIdAndDelete(req.params.id);
    if (!order) {
      return res.status(404).json({ 
        success: false,
        message: 'Заказ не найден' 
      });
    }

    // Уменьшаем счетчики в категории
    if (order.skills.length) {
      await updateSkillCounters(order.category, order.skills, 'remove');
    }

    res.json({
      success: true,
      message: 'Заказ удален'
    });
  } catch (error) {
    console.error('Error deleting order:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при удалении заказа'
    });
  }
};

// Создание предложения
export const createProposal = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { message, price, daysToComplete } = req.body;

    // Валидация
    if (!message) {
      return res.status(400).json({
        success: false,
        message: 'Сообщение обязательно'
      });
    }

    // Проверка существования заказа
    const order = await Order.findById(orderId).populate('createdBy');
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Заказ не найден'
      });
    }

    // Проверка статуса заказа
    if (order.status !== 'active') {
      return res.status(400).json({
        success: false,
        message: 'На этот заказ нельзя отправить предложение'
      });
    }

    // Проверка, что пользователь не отправляет предложение сам себе
    if (order.createdBy._id.toString() === req.user._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Вы не можете отправить предложение на свой собственный заказ'
      });
    }

    // Создание предложения
    const proposal = new Proposal({
      order: orderId,
      sender: req.user._id,
      message,
      price,
      daysToComplete,
      status: 'pending'
    });

    await proposal.save();

    // Получаем данные отправителя
    const sender = await User.findById(req.user._id);

    // Отправляем уведомление создателю заказа
    await createNotification(order.createdBy._id, {
      type: 'proposal',
      proposal: proposal._id,
      order: order._id,
      sender: req.user._id,
      message: `Новое предложение по вашему заказу "${order.title}"`
    });

    res.status(201).json({
      success: true,
      data: proposal
    });
  } catch (error) {
    console.error('Error creating proposal:', error);
    res.status(500).json({
      success: false,
      message: 'Ошибка при создании предложения',
      error: error.message
    });
  }
};

export const getUserAssignedOrders = async (req, res) => {
  try {
    const orders = await Order.find({ assignedTo: req.user._id })
      .populate('createdBy', 'firstName lastName')
      .populate('category', 'title');
      
    res.json({
      success: true,
      data: orders
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении заказов',
      error: error.message
    });
  }
};

export const updateOrderStatus = async (req, res) => {
  try {
    const { status, message } = req.body;
    const orderId = req.params.id;

    const validStatuses = ['active', 'in_progress', 'completed', 'canceled', 'pending_completion'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Некорректный статус'
      });
    }

    const order = await Order.findById(orderId)
      .populate('createdBy', 'notifications')
      .populate('assignedTo', 'notifications');
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Заказ не найден'
      });
    }

    // Проверяем, что пользователь - исполнитель заказа
    if (order.assignedTo.toString() !== req.user._id.toString() && status !== 'completed') {
      return res.status(403).json({
        success: false,
        message: 'У вас нет прав на изменение статуса этого заказа'
      });
    }

    // Если исполнитель отмечает как выполненный
    if (status === 'completed' && order.assignedTo.toString() === req.user._id.toString()) {
      // Устанавливаем промежуточный статус
      order.status = 'pending_completion';
      order.completionRequest = {
        requestedAt: new Date(),
        message: message || 'Заказ выполнен',
        attachments: req.body.attachments || []
      };
      await order.save();

      // Создаем уведомление для заказчика
      await createNotification(order.createdBy._id, {
        type: 'completionRequest',
        order: order._id,
        sender: req.user._id,
        message: `Исполнитель отметил заказ "${order.title}" как выполненный. Подтвердите завершение.`
      });

      return res.json({
        success: true,
        data: order,
        message: 'Запрос на завершение заказа отправлен заказчику'
      });
    }

    // Если заказчик подтверждает завершение
    if (status === 'completed' && order.createdBy.toString() === req.user._id.toString() && order.status === 'pending_completion') {
      order.status = 'completed';
      order.completionRequest = undefined;
      await order.save();

      // Создаем уведомление для исполнителя
      await createNotification(order.assignedTo._id, {
        type: 'orderCompleted',
        order: order._id,
        sender: req.user._id,
        message: `Заказчик подтвердил завершение заказа "${order.title}".`
      });

      return res.json({
        success: true,
        data: order,
        message: 'Заказ успешно завершен'
      });
    }

    // Если заказчик отклоняет завершение
    if (status === 'in_progress' && order.createdBy.toString() === req.user._id.toString() && order.status === 'pending_completion') {
      order.status = 'in_progress';
      order.completionRequest = undefined;
      await order.save();

      // Создаем уведомление для исполнителя
      await createNotification(order.assignedTo._id, {
        type: 'completionRejected',
        order: order._id,
        sender: req.user._id,
        message: `Заказчик отклонил завершение заказа "${order.title}". Продолжите работу.`
      });

      return res.json({
        success: true,
        data: order,
        message: 'Завершение заказа отклонено'
      });
    }

    // Стандартное обновление статуса
    order.status = status;
    await order.save();

    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при обновлении статуса заказа',
      error: error.message
    });
  }
};

export const handleCompletionResponse = async (req, res) => {
  try {
    const { accept } = req.body;
    const orderId = req.params.orderId;

    if (!mongoose.Types.ObjectId.isValid(orderId)) {
      return res.status(400).json({ 
        success: false,
        message: 'Некорректный ID заказа' 
      });
    }

    const order = await Order.findById(orderId)
      .populate('createdBy', '_id')
      .populate('assignedTo', 'notifications');
    
    if (!order) {
      return res.status(404).json({ 
        success: false,
        message: 'Заказ не найден' 
      });
    }

    // Проверяем, что пользователь - заказчик
    if (order.createdBy._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Только заказчик может подтверждать завершение'
      });
    }

    if (order.status !== 'pending_completion') {
      return res.status(400).json({
        success: false,
        message: 'Заказ не ожидает подтверждения завершения'
      });
    }

    // Обновляем статус заказа
    order.status = accept ? 'completed' : 'in_progress';
    order.completionRequest = undefined;
    await order.save();

    // Отправляем уведомление исполнителю
    if (order.assignedTo) {
      await createNotification(order.assignedTo._id, {
        type: accept ? 'orderCompleted' : 'completionRejected',
        order: order._id,
        sender: req.user._id,
        message: accept 
          ? `Заказчик подтвердил завершение заказа "${order.title}"` 
          : `Заказчик отклонил завершение заказа "${order.title}"`,
        isRead: false
      });
    }

    res.json({
      success: true,
      data: order,
      message: accept ? 'Заказ успешно завершен' : 'Завершение заказа отклонено'
    });

  } catch (error) {
    console.error('Ошибка при подтверждении завершения:', error);
    res.status(500).json({
      success: false,
      message: 'Внутренняя ошибка сервера',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

export const completeOrder = async (req, res) => {
  try {
    const { message } = req.body;
    const orderId = req.params.id;

    if (!mongoose.Types.ObjectId.isValid(orderId)) {
      return res.status(400).json({ 
        success: false,
        message: 'Некорректный ID заказа' 
      });
    }

    const order = await Order.findById(orderId)
      .populate('createdBy', 'notifications')
      .populate('assignedTo', 'notifications');
    
    if (!order) {
      return res.status(404).json({ 
        success: false,
        message: 'Заказ не найден' 
      });
    }

    // Проверяем, что пользователь - исполнитель
    if (!order.assignedTo || order.assignedTo._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Только назначенный исполнитель может завершить заказ'
      });
    }

    if (order.status !== 'in_progress') {
      return res.status(400).json({
        success: false,
        message: 'Можно завершать только заказы в статусе "В работе"'
      });
    }

    // Устанавливаем промежуточный статус
    order.status = 'pending_completion';
    order.completionRequest = {
      requestedAt: new Date(),
      message: message || 'Заказ выполнен',
      attachments: req.body.attachments || []
    };

    await order.save();

    // Отправляем уведомление заказчику
    await createNotification(order.createdBy._id, {
      type: 'completionRequest',
      order: order._id,
      sender: req.user._id,
      message: `Исполнитель запросил завершение заказа "${order.title}"`,
      isRead: false
    });

    res.json({
      success: true,
      data: order,
      message: 'Запрос на завершение отправлен заказчику'
    });

  } catch (error) {
    console.error('Ошибка при завершении заказа:', error);
    res.status(500).json({
      success: false,
      message: 'Внутренняя ошибка сервера',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};


export const getOrdersStats = async (req, res) => {
  try {
    // Получаем статистику по статусам заказов
    const statusStats = await Order.aggregate([
      {
        $group: {
          _id: "$status",
          count: { $sum: 1 },
          totalPrice: { $sum: "$price" } // Добавляем сумму цен
        }
      }
    ]);

    // Получаем динамику заказов за последние 30 дней
    const date30DaysAgo = new Date();
    date30DaysAgo.setDate(date30DaysAgo.getDate() - 30);

    const dailyStats = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: date30DaysAgo }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          count: { $sum: 1 },
          totalPrice: { $sum: "$price" } // Добавляем сумму цен
        }
      },
      { $sort: { "_id": 1 } }
    ]);

    // Статистика по выполненным заказам
    const completedStats = await Order.aggregate([
      {
        $match: {
          status: "completed"
        }
      },
      {
        $group: {
          _id: null,
          totalCompleted: { $sum: 1 },
          totalRevenue: { $sum: "$price" },
          avgPrice: { $avg: "$price" }
        }
      }
    ]);

    res.status(200).json({
      success: true,
      data: {
        statusStats,
        dailyStats,
        completedStats: completedStats[0] || {
          totalCompleted: 0,
          totalRevenue: 0,
          avgPrice: 0
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении статистики заказов',
      error: error.message
    });
  }
};

// controllers/orderController.mjs
export const analyzeProjectDescription = async (description) => {
  try {
    // Здесь можно использовать меньшую модель или API
    // Например, использовать API от Hugging Face Inference
    
    const response = await fetch('https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.HUGGINGFACE_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: `Проанализируй описание проекта и предложи:
        1. Краткое название (не более 5 слов)
        2. Ключевые навыки (не более 5)
        3. Дополнительные функции/требования
        4. Ориентировочную стоимость
        5. Категорию
        
        Описание: ${description}`
      })
    });

    const result = await response.json();
    
    // Обработка результата
    return {
      success: true,
      title: extractTitle(result),
      skills: extractSkills(result),
      features: extractFeatures(result),
      priceEstimation: extractPrice(result),
      category: extractCategory(result)
    };
    
  } catch (error) {
    console.error('AI analysis error:', error);
    return {
      success: false,
      message: 'Не удалось проанализировать описание'
    };
  }
};