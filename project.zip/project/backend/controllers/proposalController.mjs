import Proposal from '../models/Proposal.mjs';
import Order from '../models/Order.mjs';
import User from '../models/User.mjs';
import nodemailer from 'nodemailer';
import { createNotification } from './notificationController.mjs';
import { getIO } from '../config/socket.mjs';

// Конфигурация почтового сервиса
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

// Отправка уведомления создателю заказа
async function sendProposalNotification(orderOwner, proposalSender, order, proposal) {
  try {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: orderOwner.email,
      subject: 'Новое предложение по вашему заказу',
      html: `
        <h2>У вас новое предложение по заказу "${order.title}"</h2>
        <p>Пользователь ${proposalSender.firstName} ${proposalSender.lastName} отправил вам предложение:</p>
        <p><strong>Сообщение:</strong> ${proposal.message}</p>
        ${proposal.price ? `<p><strong>Предложенная цена:</strong> ${proposal.price}₽</p>` : ''}
        ${proposal.daysToComplete ? `<p><strong>Срок выполнения:</strong> ${proposal.daysToComplete} дней</p>` : ''}
        <p>Вы можете связаться с пользователем по email: ${proposalSender.email}</p>
        <p>Просмотреть заказ: <a href="${process.env.FRONTEND_URL}/orders/${order._id}">${order.title}</a></p>
      `
    };

    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending proposal notification:', error);
  }
}

// Создание предложения
export const createProposal = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { message, price, daysToComplete } = req.body;

    // Валидация
    if (!message) {
      return res.status(400).json({
        success: false,
        message: 'Сообщение обязательно'
      });
    }

    // Проверка существования заказа
    const order = await Order.findById(orderId).populate('createdBy');
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Заказ не найден'
      });
    }

    // Проверка, что пользователь не отправляет предложение сам себе
    if (order.createdBy._id.toString() === req.user._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Вы не можете отправить предложение на свой собственный заказ'
      });
    }

    // Создание предложения
    const proposal = new Proposal({
      order: orderId,
      sender: req.user._id,
      message,
      price,
      daysToComplete,
      status: 'pending'
    });

    await proposal.save();

    // Получаем данные отправителя
    const sender = await User.findById(req.user._id);

    // Отправляем уведомление создателю заказа
    await sendProposalNotification(order.createdBy, sender, order, proposal);

    // Создаем уведомление в системе
    await createNotification(order.createdBy._id, {
      type: 'proposal',
      proposal: proposal._id,
      order: order._id,
      sender: req.user._id,
      message: `Новое предложение по вашему заказу "${order.title}"`
    });

    res.status(201).json({
      success: true,
      data: proposal
    });
  } catch (error) {
    console.error('Error creating proposal:', error);
    res.status(500).json({
      success: false,
      message: 'Ошибка при создании предложения',
      error: error.message
    });
  }
};

// Получение предложений для заказа (только для создателя заказа)
export const getOrderProposals = async (req, res) => {
  try {
    const { orderId } = req.params;
    
    const proposals = await Proposal.find({ order: orderId })
      .populate('sender', 'firstName lastName email avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, data: proposals });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при получении предложений',
      error: error.message
    });
  }
};

// Получение предложений пользователя
export const getUserProposals = async (req, res) => {
  try {
    const proposals = await Proposal.find({ sender: req.user._id })
      .populate('order', 'title price daysLeft')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: proposals
    });
  } catch (error) {
    console.error('Error getting user proposals:', error);
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении ваших предложений',
      error: error.message
    });
  }
};

// Обновление статуса предложения (только для создателя заказа)
export const updateProposalStatus = async (req, res) => {
  try {
    const { proposalId } = req.params;
    const { status } = req.body;

    if (!['accepted', 'rejected'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Некорректный статус'
      });
    }

    const proposal = await Proposal.findById(proposalId)
      .populate('order')
      .populate('sender', 'email firstName lastName');

    if (!proposal) {
      return res.status(404).json({
        success: false,
        message: 'Предложение не найдено'
      });
    }

    if (proposal.order.createdBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'У вас нет прав на изменение статуса этого предложения'
      });
    }

    if (status === 'accepted') {
      const order = await Order.findById(proposal.order._id);
      
      if (order.status !== 'active') {
        return res.status(400).json({
          success: false,
          message: 'Заказ уже не активен'
        });
      }

      await Order.findByIdAndUpdate(proposal.order._id, {
        status: 'in_progress',
        acceptedProposal: proposal._id,
        assignedTo: proposal.sender._id
      });

      // Отправляем уведомление исполнителю через WebSocket
      await createNotification(proposal.sender._id, {
        type: 'orderAssigned',
        order: proposal.order._id,
        message: `Ваше предложение по заказу "${proposal.order.title}" было принято!`
      });

      await User.findByIdAndUpdate(proposal.sender._id, {
        $push: { assignedOrders: proposal.order._id }
      });
    }

    proposal.status = status;
    await proposal.save();

    res.status(200).json({
      success: true,
      data: proposal
    });
  } catch (error) {
    console.error('Error updating proposal status:', error);
    res.status(500).json({
      success: false,
      message: 'Ошибка при обновлении статуса предложения',
      error: error.message
    });
  }
};