import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import User from "../models/User.mjs";
import { sendVerificationEmail } from './emailController.mjs';

// Валидация логина (латиница)
const validateLogin = (username) => {
  const regex = /^[a-zA-Z0-9]+$/;
  return regex.test(username);
};
// Валидация имени и фамилии (кириллица или латиница)
const validateName = (name) => {
  const regex = /^[a-zA-Zа-яА-Я]+$/;
  return regex.test(name);
};

// Валидация пароля 
const validatePassword = (password) => {
  const regex = /^(?=.*\d)(?=.*[A-Z]).{8,}$/;
  return regex.test(password);
};
// Функция для генерации токена
const generateToken = (user) => {
  const payload = {
    userId: user._id,
    email: user.email,
    role: user.role 
  };
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "1h" });
};

export const register = async (req, res) => {
  try {
    const { firstName, lastName, username, email, password, confirmPassword, role } = req.body;

    // Проверка совпадения паролей
    if (password !== confirmPassword) {
      return res.status(400).json({ message: "Пароли не совпадают" });
    }

    // Валидация данных
    if (!validateName(firstName) || !validateName(lastName)) {
      return res.status(400).json({ message: "Имя и фамилия должны содержать только буквы (кириллица или латиница)." });
    }
    if (!validateLogin(username)) {
      return res.status(400).json({ message: "Логин должен содержать только латинские буквы и цифры." });
    }
    if (!validatePassword(password)) {
      return res.status(400).json({ message: "Пароль должен быть минимум 8 символов, содержать хотя бы одну цифру и одну заглавную букву." });
    }

    // Проверка существующего пользователя
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
    }

    // Хеширование пароля
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Создание пользователя
    const user = new User({
      firstName,
      lastName,
      username,
      email,
      password: hashedPassword, 
      role: role || "user",
      emailVerified: false
    });

    await user.save();
    
    try {
      // Отправляем письмо с подтверждением
      await sendVerificationEmail(user._id);
      
      res.status(201).json({ 
        message: 'Пользователь успешно зарегистрирован. На ваш email отправлен код подтверждения.',
        user,
        needsEmailVerification: true
      });
    } catch (emailError) {
      console.error('Ошибка при отправке письма:', emailError);
      
      // Удаляем пользователя, если не удалось отправить письмо
      await User.findByIdAndDelete(user._id);
      
      res.status(500).json({ 
        message: 'Ошибка при отправке письма с подтверждением',
        error: emailError.message 
      });
    }
    
  } catch (error) {
    console.error('Ошибка при регистрации:', error);
    res.status(500).json({ 
      message: 'Ошибка сервера',
      error: error.message 
    });
  }
};

export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Пользователь не найден' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: 'Неверный пароль' });
    }

    const token = generateToken(user);

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 3600000,
    });

    res.json({ token, user }); 
  } catch (error) {
    console.error('Ошибка при авторизации:', error);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

export const logout = async (req, res) => {
  try {
    // Удаляем куку с токеном с явным указанием всех параметров
    res.clearCookie('token', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production', // должно совпадать с настройками при установке куки
      sameSite: 'strict',
      path: '/', // важно указать тот же путь, что и при установке
      domain: process.env.COOKIE_DOMAIN || undefined // если используете домен
    });

    // Отправляем ответ с инструкциями для клиента
    res.status(200).json({ 
      success: true,
      message: 'Выход выполнен успешно',
      clearToken: true
    });
  } catch (error) {
    console.error('Ошибка при выходе:', error);
    res.status(500).json({ 
      success: false,
      message: 'Ошибка сервера при выходе' 
    });
  }
};

export const checkUserRole = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('role');
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    res.json({ role: user.role });
  } catch (error) {
    console.error('Ошибка при проверке роли:', error);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

export const completeGithubRegistration = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ message: "Authorization required" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { firstName, lastName, email } = req.body;

    // Validate input
    if (!firstName || !lastName || !email) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Update user
    const user = await User.findByIdAndUpdate(
      decoded.userId,
      { 
        firstName,
        lastName,
        email,
        needsCompletion: false 
      },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Generate new token without needsCompletion flag
    const newToken = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.json({ 
      success: true,
      message: "Registration completed",
      token: newToken,
      user 
    });

  } catch (error) {
    console.error("Complete registration error:", error);
    res.status(500).json({ 
      success: false,
      message: "Server error" 
    });
  }
};

// http://localhost:5000/api/auth/search?lastName=Иванов
export const searchByLastName = async (req, res) => {
  try {
    const { lastName } = req.query;

    if (!lastName || !validateName(lastName)) {
      return res.status(400).json({ 
        message: "Фамилия должна содержать только буквы (кириллица или латиница)" 
      });
    }

    // Ищем пользователей, чья фамилия начинается с введенного значения (регистронезависимо)
    const users = await User.find({
      lastName: { $regex: new RegExp(`^${lastName}`, 'i') }
    }).select('firstName lastName email role');

    if (users.length === 0) {
      return res.status(404).json({ 
        message: "Пользователи с такой фамилией не найдены" 
      });
    }

    res.json(users);
  } catch (error) {
    console.error('Ошибка при поиске пользователей:', error);
    res.status(500).json({ 
      message: 'Ошибка сервера при поиске пользователей',
      error: error.message 
    });
  }
};
export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmNewPassword } = req.body;
    const userId = req.user._id;

    // Проверка наличия всех полей
    if (!currentPassword || !newPassword || !confirmNewPassword) {
      return res.status(400).json({ 
        success: false,
        message: "Все поля обязательны для заполнения" 
      });
    }

    // Проверка совпадения новых паролей
    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ 
        success: false,
        message: "Новые пароли не совпадают" 
      });
    }

    // Валидация пароля
    if (!validatePassword(newPassword)) {
      return res.status(400).json({ 
        success: false,
        message: "Пароль должен быть минимум 8 символов, содержать цифру и заглавную букву" 
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ 
        success: false,
        message: "Пользователь не найден" 
      });
    }

    // Проверка текущего пароля
    const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ 
        success: false,
        message: "Текущий пароль введен неверно" 
      });
    }

    // Хеширование нового пароля
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);

    // Обновление пароля
    user.password = hashedPassword;
    await user.save();

    res.json({ 
      success: true,
      message: "Пароль успешно изменён" 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Ошибка сервера при смене пароля',
      error: error.message 
    });
  }
};