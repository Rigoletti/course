import Review from '../models/Review.mjs';
import Order from '../models/Order.mjs';
import User from '../models/User.mjs';

export const createReview = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { rating, comment } = req.body;
    const userId = req.user._id;

    // Проверяем, что заказ существует и завершен
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ 
        success: false,
        message: 'Заказ не найден' 
      });
    }

    if (order.status !== 'completed') {
      return res.status(400).json({ 
        success: false,
        message: 'Отзыв можно оставить только для завершенного заказа' 
      });
    }

    // Проверяем, что пользователь - заказчик
    if (order.createdBy.toString() !== userId.toString()) {
      return res.status(403).json({ 
        success: false,
        message: 'Только заказчик может оставить отзыв' 
      });
    }

    // Проверяем, что исполнитель существует
    if (!order.assignedTo) {
      return res.status(400).json({ 
        success: false,
        message: 'Исполнитель не назначен' 
      });
    }

    // Проверяем, что отзыв еще не оставлен
    const existingReview = await Review.findOne({ order: orderId });
    if (existingReview) {
      return res.status(400).json({ 
        success: false,
        message: 'Вы уже оставили отзыв на этот заказ' 
      });
    }

    // Создаем отзыв
    const review = new Review({
      order: orderId,
      reviewer: userId,
      receiver: order.assignedTo,
      rating,
      comment
    });

    await review.save();

    // Обновляем рейтинг исполнителя
    await updateUserRating(order.assignedTo);

    res.status(201).json({
      success: true,
      data: review
    });

  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при создании отзыва',
      error: error.message 
    });
  }
};

async function updateUserRating(userId) {
  const reviews = await Review.find({ receiver: userId });
  
  if (reviews.length > 0) {
    const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
    const averageRating = totalRating / reviews.length;
    
    await User.findByIdAndUpdate(userId, { 
      rating: averageRating,
      reviewsCount: reviews.length, 
      $inc: { completedOrders: 1 }
    });
  }
}

export const getOrderReview = async (req, res) => {
  try {
    const { orderId } = req.params;

    const review = await Review.findOne({ order: orderId })
      .populate('reviewer', 'firstName lastName avatar')
      .populate('receiver', 'firstName lastName');

    if (!review) {
      return res.status(404).json({ 
        success: false,
        message: 'Отзыв не найден' 
      });
    }

    res.json({
      success: true,
      data: review
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при получении отзыва',
      error: error.message 
    });
  }
};

export const getUserReviews = async (req, res) => {
  try {
    const { userId } = req.params;
    
    const reviews = await Review.find({ receiver: userId })
      .populate('reviewer', 'firstName lastName avatar')
      .populate('order', 'title')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      data: reviews
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Ошибка при получении отзывов пользователя',
      error: error.message 
    });
  }
};