import mongoose from 'mongoose';
import nodemailer from 'nodemailer';
import User from '../models/User.mjs';
import ResetCode from '../models/ResetCode.mjs';
import crypto from 'crypto';
import bcrypt from 'bcrypt';

const transporter = nodemailer.createTransport({
  host: 'smtp.mail.ru',
  port: 465,
  secure: true,
  auth: {
    user: process.env.MAILRU_EMAIL,
    pass: process.env.MAILRU_PASSWORD
  },
  tls: {
    rejectUnauthorized: false
  }
});

const generateVerificationCode = () => crypto.randomInt(100000, 999999).toString();

export const sendVerificationEmail = async (userId) => {
  try {
    const user = await User.findById(userId);
    if (!user) throw new Error('Пользователь не найден');

    const verificationCode = generateVerificationCode();
    user.emailVerificationCode = verificationCode;
    user.emailVerificationCodeExpires = Date.now() + 10 * 60 * 1000;
    await user.save();

    const mailOptions = {
      from: `"jobjuggler" <${process.env.MAILRU_EMAIL}>`,
      to: user.email,
      subject: 'Подтверждение email',
      html: `Ваш код подтверждения: ${verificationCode}`
    };

    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Ошибка отправки письма:', error);
    throw error;
  }
};

export const sendPasswordResetCode = async (email) => {
  try {
    const user = await User.findOne({ email });
    if (!user) throw new Error('Пользователь с таким email не найден');

    const code = generateVerificationCode();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await ResetCode.findOneAndUpdate(
      { userId: user._id },
      { code, expiresAt },
      { upsert: true, new: true }
    );

    const mailOptions = {
      from: `"jobjuggler" <${process.env.MAILRU_EMAIL}>`,
      to: email,
      subject: 'Сброс пароля',
      html: `Ваш код для сброса пароля: ${code}`
    };

    await transporter.sendMail(mailOptions);
    return { success: true, userId: user._id.toString() };
  } catch (error) {
    console.error('Error in sendPasswordResetCode:', error);
    throw error;
  }
};

export const verifyPasswordResetCode = async (userId, code) => {
  try {
    const resetCode = await ResetCode.findOne({ userId });
    if (!resetCode) throw new Error('Код сброса не был запрошен');
    if (resetCode.code !== code) throw new Error('Неверный код');
    if (resetCode.expiresAt < new Date()) throw new Error('Код истёк');

    return { success: true };
  } catch (error) {
    console.error('Error in verifyPasswordResetCode:', error);
    throw error;
  }
};

export const resetPassword = async (userId, newPassword) => {
  try {
    const user = await User.findById(userId);
    if (!user) throw new Error('Пользователь не найден');

    const regex = /^(?=.*\d)(?=.*[A-Z]).{8,}$/;
    if (!regex.test(newPassword)) {
      throw new Error('Пароль должен быть минимум 8 символов, содержать цифру и заглавную букву');
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);

    user.password = hashedPassword;
    await user.save();
    await ResetCode.deleteOne({ userId });

    return { success: true };
  } catch (error) {
    console.error('Error in resetPassword:', error);
    throw error;
  }
};

export const verifyEmailCode = async (userId, code) => {
  try {
    // Явно запрашиваем нужные поля
    const user = await User.findById(userId)
      .select('+emailVerificationCode +emailVerificationCodeExpires +emailVerified');
    
    if (!user) throw new Error('Пользователь не найден');
    if (user.emailVerified) throw new Error('Email уже подтверждён');
    if (!user.emailVerificationCode) throw new Error('Код не был запрошен');
    if (user.emailVerificationCode !== code) throw new Error('Неверный код');
    if (user.emailVerificationCodeExpires < Date.now()) throw new Error('Код истёк');

    user.emailVerified = true;
    user.emailVerificationCode = undefined;
    user.emailVerificationCodeExpires = undefined;
    await user.save();

    return user;
  } catch (error) {
    console.error('Ошибка подтверждения:', error);
    throw error;
  }
};


export const resendVerificationEmail = async (userId) => {
  try {
    const user = await User.findById(userId);
    if (!user) throw new Error('Пользователь не найден');
    if (user.emailVerified) throw new Error('Email уже подтверждён');

    return await sendVerificationEmail(userId);
  } catch (error) {
    console.error('Ошибка повторной отправки:', error);
    throw error;
  }
};