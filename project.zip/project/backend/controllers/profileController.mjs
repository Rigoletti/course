import jwt from "jsonwebtoken";
import User from "../models/User.mjs";
import multer from "multer";

const upload = multer();

// Получение профиля
export const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select("-password")
      .lean();

    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }

    res.json({
      message: "Данные профиля получены",
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        avatar: user.avatar,
        bio: user.bio,
        createdAt: user.createdAt,
        rating: user.rating || 0,
        reviewsCount: user.reviewsCount || 0,
        completedOrders: user.completedOrders || 0,
        balance: user.balance || 0,
        emailVerified: user.emailVerified || false
      }
    });
  } catch (error) {
    res.status(500).json({ message: "Ошибка сервера" });
  }
};
// Обновление данных профиля
export const updateProfile = async (req, res) => {
  try {
    console.log("Request body:", req.body);
    console.log("Uploaded file:", req.file);

    const updates = {};
    if (req.body.firstName) updates.firstName = req.body.firstName;
    if (req.body.lastName) updates.lastName = req.body.lastName;
    if (req.body.bio) updates.bio = req.body.bio;

    if (req.file) {
      // Используйте полный URL для аватарки
      updates.avatar = `http://localhost:5000/uploads/${req.file.filename}`;
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      updates,
      { new: true }
    ).select("-password");

    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }

    res.json({ 
      message: "Профиль успешно обновлен",
      user 
    });
  } catch (error) {
    console.error("Ошибка обновления профиля:", error);
    res.status(500).json({ 
      message: "Ошибка сервера",
      error: error.message 
    });
  }
};

// Загрузка аватарки
export const uploadAvatar = async (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Нет доступа" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId);

    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }

    console.log("Загруженный файл:", req.file); // Логируем загруженный файл

    if (!req.file) {
      return res.status(400).json({ message: "Файл не был загружен" });
    }

    // Обновляем аватар пользователя
    user.avatar = `http://localhost:5000/uploads/${req.file.filename}`;
    await user.save();

    res.json({
      message: "Аватарка успешно загружена",
      avatar: user.avatar,
    });
  } catch (error) {
    console.error("Ошибка при загрузке аватарки:", error);
    res.status(500).json({ message: "Ошибка сервера" });
  }
};
// Обновление баланса
export const updateBalance = async (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Нет доступа" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { balance } = req.body;

    const user = await User.findByIdAndUpdate(
      decoded.userId,
      { balance },
      { new: true }
    ).select("-password");

    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }

    res.json({
      message: "Баланс обновлен",
      user,
    });
  } catch (error) {
    console.error("Ошибка при обновлении баланса:", error);
    res.status(500).json({ message: "Ошибка сервера" });
  }
};