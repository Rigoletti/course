import Message from '../models/Message.mjs';
import Chat from '../models/Chat.mjs';
import Order from '../models/Order.mjs';
import { getIO } from '../config/socket.mjs';

export const sendMessage = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { content } = req.body;
    const senderId = req.user._id;

    // Проверяем, что пользователь имеет доступ к заказу
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Заказ не найден'
      });
    }

    if (senderId.toString() !== order.createdBy.toString() && 
        (!order.assignedTo || senderId.toString() !== order.assignedTo.toString())) {
      return res.status(403).json({
        success: false,
        message: 'Нет доступа к этому чату'
      });
    }

    // Создаем или находим чат
    let chat = await Chat.findOne({ order: orderId });
    if (!chat) {
      chat = new Chat({
        order: orderId,
        participants: [order.createdBy, order.assignedTo],
      });
      await chat.save();

      order.chat = chat._id;
      await order.save();
    }

    // Обработка вложений
    const attachments = [];
    if (req.files && req.files.length > 0) {
      req.files.forEach(file => {
        attachments.push({
          url: `http://localhost:5000/uploads/${file.filename}`,
          type: file.mimetype.startsWith('image/') ? 'image' : 'file',
          filename: file.originalname,
          size: file.size
        });
      });
    }

    // Создаем сообщение
    const message = new Message({
      order: orderId,
      sender: senderId,
      content: content || '',
      attachments
    });
    await message.save();

    // Добавляем сообщение в чат
    chat.messages.push(message._id);
    await chat.save();

    // Получаем полные данные сообщения
    const populatedMessage = await Message.findById(message._id)
      .populate('sender', 'firstName lastName avatar');

    // Отправляем сообщение через сокеты
    const io = getIO();
    io.to(orderId).emit('message', populatedMessage);

    res.status(201).json({
      success: true,
      data: populatedMessage
    });
  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({
      success: false,
      message: 'Ошибка при отправке сообщения',
      error: error.message
    });
  }
};
export const getChatMessages = async (req, res) => {
  try {
    const { orderId } = req.params;
    const userId = req.user._id;

    // Проверяем, что пользователь имеет доступ к заказу
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Заказ не найден'
      });
    }

    if (userId.toString() !== order.createdBy.toString() && 
        (!order.assignedTo || userId.toString() !== order.assignedTo.toString())) {
      return res.status(403).json({
        success: false,
        message: 'Нет доступа к этому чату'
      });
    }

    // Находим чат и сообщения
    const chat = await Chat.findOne({ order: orderId })
      .populate({
        path: 'messages',
        populate: {
          path: 'sender',
          select: 'firstName lastName avatar'
        }
      })
      .sort({ 'messages.timestamp': 1 });

    if (!chat) {
      return res.status(200).json({
        success: true,
        data: []
      });
    }

    res.status(200).json({
      success: true,
      data: chat.messages
    });
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении сообщений',
      error: error.message
    });
  }
};