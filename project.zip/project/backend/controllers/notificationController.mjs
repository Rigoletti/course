// controllers/notificationController.mjs
import User from '../models/User.mjs';
import Proposal from '../models/Proposal.mjs';
import Order from '../models/Order.mjs';
import { getIO } from '../config/socket.mjs';

export const getNotifications = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .populate('notifications.sender', 'firstName lastName avatar')
      .populate('notifications.proposal')
      .populate('notifications.order', 'title');

    res.status(200).json({
      success: true,
      data: user.notifications.sort((a, b) => b.createdAt - a.createdAt)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении уведомлений',
      error: error.message
    });
  }
};

export const markAsRead = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    user.notifications.forEach(notif => notif.isRead = true);
    user.unreadNotifications = 0;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Уведомления помечены как прочитанные'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при обновлении уведомлений',
      error: error.message
    });
  }
};

export const createNotification = async (userId, notificationData) => {
  try {
    const io = getIO();
    const user = await User.findById(userId);
    
    const notification = {
      ...notificationData,
      createdAt: new Date()
    };

    user.notifications.push(notification);
    user.unreadNotifications += 1;
    await user.save();

    // Отправляем уведомление через WebSocket
    io.to(`user_${userId}`).emit('newNotification', notification);
  } catch (error) {
    console.error('Error creating notification:', error);
  }
};

export const markSingleAsRead = async (req, res) => {
  try {
    const { notificationId } = req.params;
    const user = await User.findById(req.user._id);
    
    const notification = user.notifications.id(notificationId);
    if (!notification) {
      return res.status(404).json({
        success: false,
        message: 'Уведомление не найдено'
      });
    }

    if (!notification.isRead) {
      notification.isRead = true;
      user.unreadNotifications = Math.max(0, user.unreadNotifications - 1);
      await user.save();
    }

    res.status(200).json({
      success: true,
      message: 'Уведомление помечено как прочитанное'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при обновлении уведомления',
      error: error.message
    });
  }
};