import jwt from "jsonwebtoken";

export const authMiddleware = (req, res, next) => {
  let token = req.headers.authorization?.split(' ')[1];
  if (!token && req.cookies?.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return res.status(401).json({ 
      success: false,
      message: "Authorization required" 
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Проверка срока действия токена
    if (decoded.exp * 1000 < Date.now()) {
      return res.status(401).json({
        success: false,
        message: "Token expired"
      });
    }
    
    req.user = {
      _id: decoded.userId,
      role: decoded.role,
      needsCompletion: decoded.needsCompletion || false
    };
    next();
  } catch (error) {
    console.error("Token verification error:", error);
    res.status(401).json({ 
      success: false,
      message: "Invalid token" 
    });
  }
};

export const isAdmin = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ 
      success: false,
      message: "Требуется авторизация" 
    });
  }

  if (req.user.role !== 'admin') {
    return res.status(403).json({ 
      success: false,
      message: "Доступ запрещен. Требуются права администратора." 
    });
  }

  next();
};

export const isVerified = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ 
      success: false,
      message: "Требуется авторизация" 
    });
  }

  // Проверяем, подтверждён ли email (если не через GitHub)
  if (!req.user.githubId && !req.user.emailVerified) {
    return res.status(403).json({
      success: false,
      message: "Требуется подтверждение email",
      needsEmailVerification: true
    });
  }

  next();
};