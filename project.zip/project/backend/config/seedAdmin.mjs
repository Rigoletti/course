import bcrypt from "bcrypt";
import User from "../models/User.mjs";

const createAdminUser = async () => {
  try {
    const adminData = {
      firstName: "Тайлер",
      lastName: "Дерден",
      username: "admin",
      email: "admin@example.com",
      password: "Admin123$", 
      role: "admin",
      emailVerified: true,
      verificationToken: null, 
      verificationTokenExpires: null // Убираем срок действия
    };

    const existingAdmin = await User.findOne({ 
      $or: [
        { email: adminData.email },
        { username: adminData.username }
      ]
    });
    
    if (existingAdmin) {
      // Обновляем существующего админа
      existingAdmin.emailVerified = true;
      existingAdmin.verificationToken = null;
      existingAdmin.verificationTokenExpires = null;
      await existingAdmin.save();
      console.log("Администратор обновлен");
      return;
    }

    const salt = await bcrypt.genSalt(10);
    adminData.password = await bcrypt.hash(adminData.password, salt);

    const adminUser = new User(adminData);
    await adminUser.save();

    console.log("Администратор успешно создан:", adminUser.email);
  } catch (error) {
    console.error("Ошибка при создании администратора:", error);
  }
};

export default createAdminUser;