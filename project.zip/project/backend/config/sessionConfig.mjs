import session from "express-session";

const configureSession = () => {
  return session({
    secret: process.env.JWT_SECRET,
    resave: false,
    saveUninitialized: false, 
    cookie: { 
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 3600000 // 1 час
    }
  });
};

export default configureSession;