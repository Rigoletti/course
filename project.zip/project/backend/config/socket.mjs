// config/socket.mjs
import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import Order from '../models/Order.mjs';
import Chat from '../models/Chat.mjs';
import Message from '../models/Message.mjs';
import User from '../models/User.mjs';
import { createNotification } from '../controllers/notificationController.mjs';

let io;

export const initializeSocketIO = (server) => {
  io = new Server(server, {
    cors: {
      origin: "http://localhost:5173",
      methods: ["GET", "POST"],
      allowedHeaders: ["Authorization"],
      credentials: true
    },
    allowEIO3: true 
  });

  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token || 
                   socket.handshake.query?.token || 
                   (socket.handshake.headers.authorization && 
                    socket.handshake.headers.authorization.split(' ')[1]);
  
      if (!token) {
        return next(new Error('Authentication error: No token provided'));
      }
  
      jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) {
          return next(new Error('Authentication error: Invalid token'));
        }
        socket.decoded = decoded;
        socket.userId = decoded.userId; // Сохраняем ID пользователя
        next();
      });
    } catch (error) {
      next(new Error('Authentication error: ' + error.message));
    }
  });

  io.on('connection', (socket) => {
    console.log('User connected:', socket.userId);
    
    // Подписываем пользователя на его комнату для уведомлений
    socket.join(`user_${socket.userId}`);

    // Обработчик сообщений чата
    socket.on('chatMessage', async ({ orderId, content, attachments = [] }) => {
      try {
        const senderId = socket.decoded.userId;
        const order = await Order.findById(orderId);
        
        if (!order) {
          console.error('Order not found:', orderId);
          return;
        }
        
        if (senderId.toString() !== order.createdBy.toString() && 
            senderId.toString() !== order.assignedTo.toString()) {
          console.error('Unauthorized user:', senderId);
          return;
        }

        let chat = await Chat.findOne({ order: orderId });
        if (!chat) {
          chat = new Chat({
            order: orderId,
            participants: [order.createdBy, order.assignedTo],
          });
          await chat.save();

          order.chat = chat._id;
          await order.save();
        }

        const message = new Message({
          order: orderId,
          sender: senderId,
          content,
          attachments
        });
        await message.save();
        
        chat.messages.push(message._id);
        await chat.save();

        const populatedMessage = await Message.findById(message._id)
          .populate('sender', 'firstName lastName avatar');
        
        io.to(orderId).emit('message', populatedMessage);
      } catch (error) {
        console.error("Error handling chat message:", error);
      }
    });

    socket.on('joinRoom', (orderId) => {
      socket.join(orderId);
      console.log(`User ${socket.userId} joined room ${orderId}`);
    });

    // Отправка уведомления конкретному пользователю
    socket.on('sendNotification', async ({ userId, notificationData }) => {
      try {
        const user = await User.findById(userId);
        if (!user) {
          console.error('User not found:', userId);
          return;
        }

        const notification = {
          ...notificationData,
          createdAt: new Date()
        };

        user.notifications.push(notification);
        user.unreadNotifications += 1;
        await user.save();

        // Отправляем уведомление конкретному пользователю
        io.to(`user_${userId}`).emit('newNotification', notification);
      } catch (error) {
        console.error('Error sending notification:', error);
      }
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.userId);
    });
  });
};

export const getIO = () => {
  if (!io) {
    throw new Error("Socket.IO has not been initialized. Please call initializeSocketIO first.");
  }
  return io;
};

// Вспомогательная функция для отправки уведомлений
export const sendNotification = (userId, notificationData) => {
  if (io) {
    io.emit('sendNotification', { userId, notificationData });
  }
};