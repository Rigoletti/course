import express from "express";
import dotenv from "dotenv";
import connectDB from "./config/db_connect.mjs";
import passport from "passport";
import configurePassport from "./config/passportConfig.mjs";
import configureSession from "./config/sessionConfig.mjs";
import configureCors from "./config/corsConfig.mjs";
import authRoutes from "./routes/authRoutes.mjs";
import profileRoutes from "./routes/profileRoutes.mjs";
import githubRoutes from "./routes/githubRoutes.mjs";
import categoryRoutes from "./routes/categoryRoutes.mjs";
import orderRoutes from './routes/orderRoutes.mjs';
import proposalRoutes from './routes/proposalRoutes.mjs';
import notificationRoutes from './routes/notificationRoutes.mjs'
import path from "path";
import fs from "fs";
import cookieParser from "cookie-parser";
import { fileURLToPath } from 'url';
import reviewRoutes from './routes/reviewRoutes.mjs';
import { initializeSocketIO } from './config/socket.mjs'; 
import messageRoutes from './routes/messageRoutes.mjs';
import emailRoutes from './routes/emailRoutes.mjs';
import createAdminUser from "./config/seedAdmin.mjs";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

// Создание папки uploads, если она не существует
const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  console.log("Папка uploads создана");
}

// Подключение middleware
app.use(configureCors());
app.use(express.json());
app.use(cookieParser());
app.use(configureSession());

// Раздача статических файлов
app.use("/uploads", express.static(uploadsDir));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
// Подключение к базе данных
connectDB();

// Настройка Passport
configurePassport();
app.use(passport.initialize());
app.use(passport.session());

// Маршруты
app.use("/api/auth", authRoutes); 
app.use("/api/profile", profileRoutes);
app.use("/api/auth/github", githubRoutes); 
app.use("/api/categories", categoryRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api', proposalRoutes)
app.use('/api/notifications', notificationRoutes);
app.use('/api', reviewRoutes);
app.use('/api', messageRoutes);
app.use("/api/email", emailRoutes);

// Обработка ошибок
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Внутренняя ошибка сервера',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Запуск сервера
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, async () => {
  console.log(`Сервер запущен на порту ${PORT}`);
  
  // Создаем администратора при запуске
  await createAdminUser();
});

// Инициализация Socket.IO после создания сервера
initializeSocketIO(server);
