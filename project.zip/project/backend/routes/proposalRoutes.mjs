import express from 'express';
import { 
  createProposal,
  getOrderProposals,
  getUserProposals,
  updateProposalStatus
} from '../controllers/proposalController.mjs';
import { authMiddleware } from '../middleware/authMiddleware.mjs';

const router = express.Router();

// Создание предложения (для всех авторизованных пользователей)
router.post('/orders/:orderId/proposals', authMiddleware, createProposal);

// Получение предложений для заказа (только для создателя заказа)
router.get('/orders/:orderId/proposals', authMiddleware, getOrderProposals);

// Получение предложений текущего пользователя
router.get('/users/proposals', authMiddleware, getUserProposals);

// Обновление статуса предложения (только для создателя заказа)
router.put('/proposals/:proposalId/status', authMiddleware, updateProposalStatus);

export default router;