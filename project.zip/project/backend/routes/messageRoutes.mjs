import express from 'express';
import { authMiddleware } from '../middleware/authMiddleware.mjs';
import { sendMessage, getChatMessages } from '../controllers/messageController.mjs';
import upload from '../config/multerConfig.mjs';

const router = express.Router();

// Отправка сообщения (с поддержкой файлов)
router.post('/orders/:orderId/messages', 
  authMiddleware, 
  upload.array('attachments', 5), // Максимум 5 файлов
  sendMessage
);

// Получение сообщений чата
router.get('/orders/:orderId/messages', authMiddleware, getChatMessages);

export default router;