import express from 'express';
import { 
  // Основные операции с заказами
  createOrder,
  getOrders,
  getOrderById,
  updateOrder,
  deleteOrder,
  getOrdersByCategory,
  createOrderRequest,
  getOrderRequests,
  approveOrderRequest,
  rejectOrderRequest,
  getUserAssignedOrders,
  updateOrderStatus,
  handleCompletionResponse,
  completeOrder,
  getOrdersStats
} from '../controllers/orderController.mjs';
import { authMiddleware, isAdmin } from '../middleware/authMiddleware.mjs';
import { analyzeProjectDescription } from '../services/aiService.mjs';

const router = express.Router();
router.get('/', getOrders); // Получить список заказов
router.get('/category/:categoryId', getOrdersByCategory); // Заказы по категории
router.get('/:id', getOrderById); // Получить заказ по ID
router.post('/requests', authMiddleware, createOrderRequest); // Создать заявку на заказ
router.put('/:id/status', authMiddleware, updateOrderStatus);
// Основные операции с заказами
router.post('/', authMiddleware, isAdmin, createOrder); // Создать заказ (админ)
router.put('/:id', authMiddleware, isAdmin, updateOrder); // Обновить заказ
router.delete('/:id', authMiddleware, isAdmin, deleteOrder); // Удалить заказ

// Управление заявками
router.get('/admin/requests', authMiddleware, isAdmin, getOrderRequests); // Получить список заявок
router.put('/admin/requests/:id/approve', authMiddleware, isAdmin, approveOrderRequest); // Одобрить заявку
router.put('/admin/requests/:id/reject', authMiddleware, isAdmin, rejectOrderRequest); // Отклонить заявку
router.get('/user/assigned', authMiddleware, getUserAssignedOrders);

router.put('/:id/status', authMiddleware, updateOrderStatus);
router.put('/:orderId/completion', authMiddleware, handleCompletionResponse);

router.put('/:id/complete', authMiddleware, completeOrder);
router.put('/:id/completion', authMiddleware, handleCompletionResponse);

router.get('/admin/stats', authMiddleware, isAdmin, getOrdersStats);


router.post('/analyze-description', (req, res) => {
  try {
    const { description, price } = req.body;
    console.log('Received request:', { description, price }); // Логируем входящий запрос
    
    const result = analyzeProjectDescription(description, price);
    console.log('Sending response:', result); // Логируем ответ
    
    res.json(result);
  } catch (error) {
    console.error('Error in analyze-description:', error);
    res.status(500).json({
      success: false,
      message: 'Ошибка при анализе описания'
    });
  }
});

export default router;