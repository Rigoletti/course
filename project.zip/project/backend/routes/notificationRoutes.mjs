import express from 'express';
import { getNotifications, markAsRead, markSingleAsRead } from '../controllers/notificationController.mjs';
import { authMiddleware } from '../middleware/authMiddleware.mjs';

const router = express.Router();

router.get('/', authMiddleware, getNotifications);
router.put('/mark-as-read', authMiddleware, markAsRead);
router.patch('/:notificationId', authMiddleware, markSingleAsRead);
export default router;