import express from "express";
import * as authController from "../controllers/authController.mjs";
import { authMiddleware } from "../middleware/authMiddleware.mjs";

const router = express.Router();

// Регистрация
router.post("/register", authController.register);

// Вход
router.post("/login", authController.login);

router.get("/search", authController.searchByLastName)

// Исправленный маршрут проверки роли - используем контроллер
router.get("/check-role", authMiddleware, authController.checkUserRole);

router.post("/complete-github-registration", authMiddleware, authController.completeGithubRegistration);
router.post("/change-password", authMiddleware, authController.changePassword);
// Выход
router.post("/logout", authController.logout);

export default router;