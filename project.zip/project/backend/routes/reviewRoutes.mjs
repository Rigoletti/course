import express from 'express';
import { 
  createReview, 
  getOrderReview,
  getUserReviews
} from '../controllers/reviewController.mjs';
import { authMiddleware } from '../middleware/authMiddleware.mjs';

const router = express.Router();

router.post('/orders/:orderId/reviews', authMiddleware, createReview);
router.get('/orders/:orderId/reviews', getOrderReview);
router.get('/users/:userId/reviews', getUserReviews);
router.get('/users/me/reviews', authMiddleware, (req, res) => {
  // Перенаправляем запрос с текущим userId
  req.params.userId = req.user._id;
  return getUserReviews(req, res);
});

export default router;