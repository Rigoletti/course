import express from 'express';
import { 
  sendPasswordResetCode,
  verifyPasswordResetCode,
  resetPassword,
  verifyEmailCode,
  resendVerificationEmail
} from '../controllers/emailController.mjs';
import { authMiddleware } from '../middleware/authMiddleware.mjs';

const router = express.Router();

router.post('/verify-email', authMiddleware, async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) return res.status(400).json({ success: false, message: 'Код обязателен' });

    const user = await verifyEmailCode(req.user._id, code);
    res.json({ 
      success: true,
      message: 'Email подтверждён',
      user: {
        _id: user._id,
        email: user.email,
        emailVerified: user.emailVerified
      }
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/resend-verification', authMiddleware, async (req, res) => {
  try {
    await resendVerificationEmail(req.user._id);
    res.json({ success: true, message: 'Код отправлен повторно' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/request-password-reset', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ success: false, message: 'Email обязателен' });

    const result = await sendPasswordResetCode(email);
    res.json({ 
      success: true,
      message: 'Код для сброса пароля отправлен на email',
      userId: result.userId
    });
  } catch (error) {
    console.error('Error in request-password-reset:', error);
    res.status(400).json({ 
      success: false, 
      message: error.message 
    });
  }
});

router.post('/verify-password-reset-code', async (req, res) => {
  try {
    const { userId, code } = req.body;
    if (!userId || !code) {
      return res.status(400).json({ 
        success: false, 
        message: 'ID пользователя и код обязательны' 
      });
    }

    await verifyPasswordResetCode(userId, code);
    res.json({ 
      success: true,
      message: 'Код подтверждён'
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/reset-password', async (req, res) => {
  try {
    const { userId, newPassword } = req.body;
    if (!userId || !newPassword) {
      return res.status(400).json({ 
        success: false, 
        message: 'ID пользователя и новый пароль обязательны' 
      });
    }

    await resetPassword(userId, newPassword);
    res.json({ 
      success: true,
      message: 'Пароль успешно изменён'
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;