import express from "express";
import { 
  getProfile, 
  updateProfile, 
  updateBalance 
} from "../controllers/profileController.mjs";
import upload from "../config/multerConfig.mjs";
import { authMiddleware } from "../middleware/authMiddleware.mjs";

const router = express.Router();

router.get("/", authMiddleware, getProfile);
router.put("/", authMiddleware, upload.single("avatar"), updateProfile);
router.put("/update-balance", authMiddleware, updateBalance);

export default router;