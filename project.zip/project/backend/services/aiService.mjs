

export const analyzeProjectDescription = (description, userPrice = 0) => {
  console.log('Анализируем описание:', description);
  const context = analyzeTextContext(description);
  console.log('Определенный контекст:', context);
  
  const result = {
    success: true,
    data: {
      title: generateTitle(description, context),
      skills: getSkills(context),
      features: getFeatures(context),
      category: context.category
    }
  };
  
  console.log('Результат анализа:', result);
  return result;
};
function detectIndustry(text) {
  const industries = {
    freelance: /фриланс|биржа|заказчик|исполнитель|удаленк/i,
    food: /кафе|ресторан|еда|продукт|бариста|доставк|питани/i,
    tech: /технолог|it|софт|программ|приложен|сайт|компьютер/i,
    retail: /магазин|торговл|розниц|продаж|товар|интернет-магазин/i,
    service: /услуг|сервис|обслуживан|заказ|бронирован/i,
    sport: /спорт|футбол|клуб|команд|тренировк/i,
    education: /образован|обучен|курс|школ|университет/i,
    finance: /финанс|банк|кредит|инвест|крипто|bitcoin/i,
    entertainment: /развлечен|кино|музык|игр|медиа/i
  };
  
  for (const [industry, regex] of Object.entries(industries)) {
    if (regex.test(text)) return industry;
  }
  return 'general';
}

// Глубокий анализ контекста с улучшенной логикой
function analyzeTextContext(text) {
  const lowerText = text.toLowerCase();
  
  // Улучшенное определение категории
  let category = 'other';
  const categories = {
    design: /лого|дизайн|бренд|стиль|анимац|иллюстрац|график|шрифт|типографик|визитк|баннер|постер|рисун|арт|обложк|иконк/i,
    web: /сайт|веб|интернет|магазин|лендинг|портал|html|css|js|javascript|frontend|backend|fullstack|react|angular|vue|node|next|nuxt|svelte|shopify|wordpress|joomla|drupal/i,
    app: /приложен|мобильн|ios|android|гибридн|flutter|react native|кроссплатформен|api|интерфейс|ui|ux|десктоп|desktop/i,
    marketing: /маркетинг|продвижен|реклам|smm|таргет|seo|контекст|трафик|аналитик|конверсия|копитент/i,
    text: /текст|копирайт|перевод|стать|рерайт|контент|описан|слоган|рассказ|роман|повесть|книг|литератур|писател/i,
    video: /видео|монтаж|ролик|анимац|мультик|тизер|трейлер|рекламн|клип|фильм|кино/i,
    audio: /аудио|озвучк|подкаст|запис|звук|музык|саунд|трек|композиц|микш|хоррор|игр|game/i,
    game: /игр|game|гейм|unity|unreal|движок|персонаж|локац|геймплей/i,
    software: /программ|софт|утилит|управлен|систем|desktop|десктоп|баз|данн|sql/i
  };
  
  // Приоритетная проверка для более специфичных категорий
  if (categories.audio.test(lowerText)) {
    if (/(игр|game|хоррор)/i.test(lowerText)) category = 'game_audio';
    else category = 'audio';
  } 
  else if (categories.game.test(lowerText)) category = 'game';
  else {
    for (const [cat, regex] of Object.entries(categories)) {
      if (regex.test(lowerText)) {
        category = cat;
        break;
      }
    }
  }
  
  // Улучшенное определение специфики
  const specifics = {
    target: extractTarget(lowerText),
    complexity: estimateComplexity(text),
    industry: detectIndustry(lowerText),
    techStack: detectTechStack(lowerText),
    genre: detectGenre(lowerText),
    length: detectLength(text)
  };
  
  return { category, ...specifics };
}

// Извлечение цели проекта с улучшенной логикой
function extractTarget(text) {
  const targetRegexes = [
    /(?:для|под|проект|заказ|лого|сайт|приложен|игр|музык|трек|рассказ)\s+"([^"]+)"/i,
    /(?:для|под|проект|заказ)\s+([а-яё\s\-]{3,})(?:$|\s|\.|\,)/i,
    /(?:название|назовите|именем)\s+"([^"]+)"/i
  ];
  
  for (const regex of targetRegexes) {
    const match = text.match(regex);
    if (match) return match[1].trim();
  }
  
  return null;
}

// Оценка сложности с дополнительными критериями
function estimateComplexity(text) {
  const wordCount = text.split(/\s+/).length;
  
  if (/(сложн|многофункци|интеграц|кастомн|индивидуальн|уникальн|полн|автоматизац|собствен)/i.test(text) 
    || wordCount > 100) return 'high';
  if (/(прост|базов|стандарт|типов|шаблон|быстр|небольш|мал|коротк)/i.test(text) 
    || wordCount < 30) return 'low';
  return 'medium';
}

// Определение жанра для текстовых/аудио/видео проектов
function detectGenre(text) {
  const genres = {
    horror: /хоррор|ужас|страшн|мистик/i,
    romance: /роман|любов|романтик|чувств/i,
    action: /экшен|боевик|драк|стреля/i,
    fantasy: /фэнтези|маги|волшеб|эльф|орк/i,
    scifi: /фантаст|космос|пришеле|робот/i,
    business: /бизнес|стартап|коммер/i,
    educational: /обуч|образован|курс|школ/i
  };
  
  for (const [genre, regex] of Object.entries(genres)) {
    if (regex.test(text)) return genre;
  }
  return null;
}

// Определение объема текста
function detectLength(text) {
  const charCount = text.length;
  if (charCount > 30000) return 'large';
  if (charCount > 10000) return 'medium';
  return 'small';
}

// Улучшенное определение технологий
function detectTechStack(text) {
  const techs = new Set();
  
  // Веб-технологии
  if (/html|css|javascript|js/i.test(text)) {
    techs.add('HTML5/CSS3');
    techs.add('JavaScript (ES6+)');
  }
  
  // Фронтенд фреймворки
  if (/react/i.test(text)) techs.add('React');
  if (/angular/i.test(text)) techs.add('Angular');
  if (/vue/i.test(text)) techs.add('Vue.js');
  if (/svelte/i.test(text)) techs.add('Svelte');
  
  // Бэкенд технологии
  if (/node/i.test(text)) techs.add('Node.js');
  if (/express/i.test(text)) techs.add('Express');
  if (/django/i.test(text)) techs.add('Django');
  if (/flask/i.test(text)) techs.add('Flask');
  if (/laravel/i.test(text)) techs.add('Laravel');
  if (/spring/i.test(text)) techs.add('Spring Boot');
  
  // Мобильная разработка
  if (/flutter/i.test(text)) techs.add('Flutter');
  if (/react native/i.test(text)) techs.add('React Native');
  if (/kotlin/i.test(text)) techs.add('Kotlin');
  if (/swift/i.test(text)) techs.add('Swift');
  
  // CMS и e-commerce
  if (/wordpress/i.test(text)) techs.add('WordPress');
  if (/shopify/i.test(text)) techs.add('Shopify');
  if (/magento/i.test(text)) techs.add('Magento');
  
  // Базы данных
  if (/mongodb/i.test(text)) techs.add('MongoDB');
  if (/postgres/i.test(text)) techs.add('PostgreSQL');
  if (/mysql/i.test(text)) techs.add('MySQL');
  
  return techs.size > 0 ? Array.from(techs) : null;
}

// Улучшенная генерация названия
function generateTitle(text, { category, target, industry, genre, length }) {
  // Специальные обработчики для разных категорий
  switch(category) {
    case 'audio':
      if (genre === 'horror') {
        return target 
          ? `Саундтрек для хоррор-игры "${target}"`
          : `Музыка для хоррор-игры`;
      }
      return target 
        ? `Создание музыки для "${target}"`
        : 'Музыкальный проект';
    
    case 'text':
      if (genre === 'romance') {
        return target
          ? `Романтический рассказ "${target}"`
          : length === 'large'
            ? 'Романтический роман'
            : 'Романтический рассказ';
      }
      return target
        ? `Текстовый контент "${target}"`
        : 'Написание текста';
    
    case 'game_audio':
      return target
        ? `Звуковое оформление для игры "${target}"`
        : 'Аудиодизайн для игры';
    
    case 'web':
      if (/(магазин|e.?commerce)/i.test(text)) {
        return target
          ? `Интернет-магазин "${target}"`
          : 'Разработка интернет-магазина';
      }
      return target
        ? `Веб-сайт "${target}"`
        : 'Разработка веб-сайта';
    
    default:
      // Общий шаблон для остальных категорий
      const categoryTitles = {
        design: `Дизайн ${target ? `"${target}"` : 'проекта'}`,
        app: `Приложение ${target ? `для "${target}"` : ''}`.trim(),
        marketing: `Продвижение ${target ? `"${target}"` : ''}`.trim(),
        video: `Видео ${target ? `"${target}"` : 'производство'}`,
        game: `Игра ${target ? `"${target}"` : ''}`.trim(),
        software: `Программное обеспечение ${target ? `для "${target}"` : ''}`.trim()
      };
      
      return categoryTitles[category] || `Проект: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}`;
  }
}

// Улучшенный подбор навыков
function getSkills({ category, complexity, industry, genre, techStack }) {
  const baseSkills = {
    // Дизайн
    design: [
      'Adobe Illustrator', 'Photoshop', 'Figma', 'CorelDRAW',
      'Графический дизайн', 'UI/UX', 'Типографика', 'Брендинг'
    ],
    
    // Веб-разработка
    web: [
      'HTML5/CSS3', 'JavaScript (ES6+)', 'Адаптивная верстка',
      'UI/UX', 'Cross-browser development', 'Web Performance'
    ],
    
    // Мобильная разработка
    app: [
      'Мобильная разработка', 'UI/UX', 'API интеграции',
      'Кроссплатформенность', 'Material Design', 'App Store Optimization'
    ],
    
    // Маркетинг
    marketing: [
      'SMM', 'Копирайтинг', 'Аналитика', 'Таргетированная реклама',
      'SEO', 'Контент-стратегия', 'Google Analytics'
    ],
    
    // Тексты
    text: [
      'Копирайтинг', 'Литературное мастерство', 'Грамотность',
      'Стилистика', 'Редактура', 'Сторителлинг'
    ],
    
    // Аудио
    audio: [
      'Sound Design', 'Композиция', 'MIDI программирование',
      'Аранжировка', 'Сведение', 'Мастеринг'
    ],
    
    // Аудио для игр
    game_audio: [
      'FMOD', 'Wwise', 'Unity Audio', 'Sound Design',
      'Атмосферные звуки', 'Создание спецэффектов', 'Интерактивная музыка'
    ],
    
    // Видео
    video: [
      'Adobe Premiere', 'After Effects', 'DaVinci Resolve',
      'Цветокоррекция', 'Монтаж', 'Сценаристика', 'Motion Design'
    ],
    
    // Игры
    game: [
      'Unity', 'Unreal Engine', 'C#', 'C++',
      'Game Design', '3D Modeling', 'Level Design'
    ],
    
    // ПО
    software: [
      'Архитектура ПО', 'Базы данных', 'API design',
      'Тестирование', 'Документирование', 'DevOps'
    ]
  };
  
  const additionalSkills = {
    // По сложности
    high: [
      'Сложные интеграции', 'Кастомные решения', 'Архитектурное проектирование',
      'Оптимизация производительности', 'Собственные разработки'
    ],
    medium: [
      'Интеграция API', 'Базовая оптимизация', 'Тестирование'
    ],
    
    // По жанрам
    horror: [
      'Создание атмосферы', 'Звуковые эффекты ужаса', 'Психоакустика'
    ],
    romance: [
      'Создание эмоциональных текстов', 'Развитие персонажей', 'Диалоги'
    ],
    
    // По отраслям
    food: [
      'Фуд-фотография', 'Знание индустрии питания', 'Продвижение ресторанов'
    ],
    tech: [
      'Техническая экспертиза', 'Документирование API', 'Интеграции'
    ],
    retail: [
      'Опыт в e-commerce', 'Платежные системы', 'CRM интеграции'
    ],
    sport: [
      'Спортивный брендинг', 'Дизайн атрибутики', 'Маркетинг в спорте'
    ],
    finance: [
      'Финансовая грамотность', 'Блокчейн', 'Криптовалюты', 'Безопасность'
    ],
    education: [
      'Педагогический дизайн', 'e-Learning', 'Интерактивные курсы'
    ]
  };
  
  // Начинаем с базовых навыков для категории
  let skills = new Set(baseSkills[category] || baseSkills.other);
  
  // Добавляем навыки по сложности
  if (additionalSkills[complexity]) {
    additionalSkills[complexity].forEach(skill => skills.add(skill));
  }
  
  // Добавляем навыки по жанру
  if (genre && additionalSkills[genre]) {
    additionalSkills[genre].forEach(skill => skills.add(skill));
  }
  
  // Добавляем навыки по отрасли
  if (industry && additionalSkills[industry]) {
    additionalSkills[industry].forEach(skill => skills.add(skill));
  }
  
  // Добавляем технические навыки, если они указаны
  if (techStack) {
    techStack.forEach(tech => skills.add(tech));
  }
  
  // Специальные случаи
  if (category === 'web') {
    skills.add('Responsive Design');
    if (complexity === 'high') {
      skills.add('Progressive Web Apps');
      skills.add('Web Accessibility');
    }
  }
  
  if (category === 'game_audio') {
    skills.add('Интерактивное аудио');
    skills.add('Адаптивная музыка');
  }
  
  if (category === 'text' && genre === 'romance') {
    skills.add('Эмоциональный копирайтинг');
    skills.add('Развитие сюжета');
  }
  
  // Преобразуем в массив и сортируем
  return Array.from(skills).sort().slice(0, 6); // Максимум 6 навыков
}

// Улучшенное предложение функций
function getFeatures({ category, complexity, industry, genre, length }) {
  const features = {
    // Аудио
    audio: [
      'Оригинальная композиция',
      'Сведение и мастеринг',
      complexity === 'high' ? 'Несколько вариантов' : 'Один финальный вариант',
      'Формат: WAV, MP3',
      genre === 'horror' ? 'Атмосферные звуковые эффекты' : null
    ].filter(Boolean),
    
    // Аудио для игр
    game_audio: [
      'Интерактивная музыка',
      'Звуковые эффекты персонажей',
      'Атмосферные звуки окружения',
      'Адаптация под игровой процесс',
      'Интеграция с игровым движком'
    ].filter(Boolean),
    
    // Тексты
    text: [
      length === 'large' ? 'Полноценный сюжет' : 'Завершенная история',
      'Развитие персонажей',
      genre === 'romance' ? 'Романтическая линия' : null,
      'Редактура и корректура',
      'Форматирование текста'
    ].filter(Boolean),
    
    // Веб
    web: [
      'Адаптивный дизайн',
      industry === 'freelance' ? 'Личные кабинеты пользователей' : 'Контактная форма',
      industry === 'freelance' ? 'Система заказов' : 'SEO оптимизация',
      industry === 'freelance' ? 'Платежная система' : 'Интеграция с соцсетями',
      complexity === 'high' ? 'Кастомная разработка' : 'Готовая CMS',
      industry === 'freelance' ? 'Модерация заказов' : null
    ].filter(Boolean),
    
    
    // Дизайн
    design: [
      '3 варианта концепции',
      'Гайд по использованию',
      complexity === 'high' ? 'Анимация элементов' : 'Статичный дизайн',
      'Адаптация под разные носители',
      industry === 'sport' ? 'Дизайн формы' : null
    ].filter(Boolean),
    
    // Приложения
    app: [
      'Кроссплатформенность',
      complexity === 'high' ? 'Оффлайн-режим' : 'Базовый функционал',
      'Push-уведомления',
      'Аналитика использования',
      industry === 'food' ? 'Система бронирования' : null
    ].filter(Boolean),
    
    // Маркетинг
    marketing: [
      'Анализ конкурентов',
      complexity === 'high' ? 'Полный комплекс' : 'Базовый пакет',
      'Отчетность',
      'A/B тестирование',
      industry === 'tech' ? 'Технический копирайтинг' : null
    ].filter(Boolean),
    
    // Игры
    game: [
      'Проектирование механик',
      complexity === 'high' ? 'Кастомный движок' : 'Готовый движок',
      'Дизайн уровней',
      'Балансировка игрового процесса',
      genre === 'horror' ? 'Атмосфера ужаса' : null
    ].filter(Boolean)
  };
  
  // Возвращаем специфичные для категории функции или общие
  return features[category] || [
    complexity === 'high' ? 'Индивидуальный подход' : 'Стандартное решение',
    'Техническая документация',
    'Поддержка после завершения',
    'Исходные материалы'
  ];
}