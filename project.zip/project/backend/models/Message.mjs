import mongoose from 'mongoose';

const messageSchema = new mongoose.Schema({
  order: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Order',
    required: true
  },
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  content: {
    type: String,
    required: function() { return !this.attachments || this.attachments.length === 0; }
  },
  attachments: [{
    url: String,
    type: {
      type: String,
      enum: ['image', 'file'],
      default: 'image'
    },
    filename: String,
    size: Number
  }],
  timestamp: {
    type: Date,
    default: Date.now
  }
});

const Message = mongoose.model('Message', messageSchema);

export default Message;
