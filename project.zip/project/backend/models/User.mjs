import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  firstName: { type: String, required: true, trim: true },
  lastName: { type: String, required: true, trim: true },
  username: { type: String, required: true, unique: true, trim: true },
  email: { type: String, required: true, unique: true, trim: true, lowercase: true },
  password: { type: String, minlength: 6 },
  role: { type: String, enum: ["user", "admin"], default: "user" },
  githubId: { type: String, unique: true, sparse: true },
  needsCompletion: { type: Boolean, default: false },
  avatar: { type: String, default: "" },
  bio: { type: String, default: "" },
  balance: { type: Number, default: 0 },
  completedOrders: { type: Number, default: 0 },
  rating: { type: Number, default: 0 },
  reviewsCount: { type: Number, default: 0 },
  reviews: [{ type: String }],
  notifications: [{
    type: {
      type: String,
      enum: ['proposal', 'statusChange', 'message', 'orderAssigned', 'completionRequest', 'orderCompleted', 'completionRejected'],
      required: true
    },
    proposal: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Proposal'
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Order'
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    message: String,
    isRead: {
      type: Boolean,
      default: false
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  assignedOrders: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Order'
  }],
  unreadNotifications: {
    type: Number,
    default: 0
  },
  emailVerified: {
    type: Boolean,
    default: false
  },
  emailVerificationCode: {
    type: String,
    select: false
  },
  emailVerificationCodeExpires: {
    type: Date,
    select: false
  }
}, { 
  timestamps: true,
  toObject: { virtuals: true },
  toJSON: { virtuals: true }
});

userSchema.post('save', function(doc) {
  console.log('User saved:', doc._id);
});

export default mongoose.model("User", userSchema);