import mongoose from 'mongoose';

const resetCodeSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true // Один код на пользователя
  },
  code: {
    type: String,
    required: true
  },
  expiresAt: {
    type: Date,
    required: true,
    index: { expires: '10m' } // Автоматическое удаление через 10 минут
  }
});

const ResetCode = mongoose.model('ResetCode', resetCodeSchema);

export default ResetCode;