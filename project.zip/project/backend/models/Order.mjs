import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  daysLeft: {
    type: Number,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  skills: [String],
  price: {
    type: Number,
    required: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'in_progress', 'completed', 'canceled', 'pending_completion'],
    default: 'active'
  },
  acceptedProposal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Proposal'
  },
  completionRequest: {
    requestedAt: Date,
    message: String,
    attachments: [String]
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  chat: { 
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Chat' 
  },
});

orderSchema.index({ category: 1 });
orderSchema.index({ skills: 1 });
orderSchema.index({ status: 1 });

orderSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const Order = mongoose.model('Order', orderSchema);

export default Order;