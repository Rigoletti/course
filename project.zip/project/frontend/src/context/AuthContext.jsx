import { createContext, useContext, useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const initializeAuth = async () => {
      const token = localStorage.getItem('token');
      
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        // Декодируем токен для получения базовых данных
        const decoded = jwtDecode(token);
        
        // Проверяем срок действия токена
        if (decoded.exp * 1000 < Date.now()) {
          throw new Error('Token expired');
        }

        // Устанавливаем пользователя из токена
        const userData = {
          token,
          role: decoded.role,
          userId: decoded.userId,
          email: decoded.email
        };
        
        setCurrentUser(userData);
        
        // Пытаемся проверить роль через API (но не блокируем инициализацию при ошибке)
        try {
          const response = await axios.get('/api/auth/check-role', {
            headers: { Authorization: `Bearer ${token}` }
          });
          
          // Обновляем роль если она изменилась
          if (response.data.role && response.data.role !== decoded.role) {
            setCurrentUser(prev => ({ ...prev, role: response.data.role }));
          }
        } catch (apiError) {
          console.warn('Role check warning:', apiError.message);
          // Продолжаем с данными из токена
        }

      } catch (error) {
        console.error('Auth error:', error.message);
        handleLogout();
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    setCurrentUser(null);
    navigate('/authorization');
  };

  const login = async (userData) => {
    localStorage.setItem('token', userData.token);
    const decoded = jwtDecode(userData.token);
    setCurrentUser({
      token: userData.token,
      role: decoded.role,
      userId: decoded.userId,
      email: decoded.email,
      ...userData.user
    });
  };

  const logout = handleLogout;

  const value = {
    currentUser,
    login,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}