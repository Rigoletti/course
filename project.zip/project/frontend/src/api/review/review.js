import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export const createReview = async (orderId, reviewData) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Требуется авторизация');
    }

    const response = await axios.post(
      `${API_BASE_URL}/orders/${orderId}/reviews`,
      reviewData,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Ошибка при создании отзыва' };
  }
};

export const getOrderReview = async (orderId) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/orders/${orderId}/reviews`);
    return response.data;
  } catch (error) {
    if (error.response?.status === 404) {
      return { success: false, data: null };
    }
    throw error.response?.data || { message: 'Ошибка при получении отзыва' };
  }
};

export const getUserReviews = async (userId) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/users/${userId}/reviews`);
    return response.data;
  } catch (error) {
    if (error.response?.status === 404) {
      return { success: false, data: [] };
    }
    throw error.response?.data || { message: 'Ошибка при получении отзывов пользователя' };
  }
};

export const getCurrentUserReviews = async () => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Требуется авторизация');
    }

    const response = await axios.get(`${API_BASE_URL}/users/me/reviews`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Ошибка при получении ваших отзывов' };
  }
};