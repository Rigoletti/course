import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api/notifications';

export const getNotifications = async () => {
  try {
    const token = localStorage.getItem('token');
    if (!token) throw new Error('Требуется авторизация');

    const response = await axios.get(API_BASE_URL, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Ошибка при получении уведомлений' };
  }
};

export const markAsRead = async () => {
  try {
    const token = localStorage.getItem('token');
    if (!token) throw new Error('Требуется авторизация');

    const response = await axios.put(`${API_BASE_URL}/mark-as-read`, {}, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Ошибка при обновлении уведомлений' };
  }
};

// функция для отметки одного уведомления как прочитанного
export const markNotificationAsRead = async (notificationId) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) throw new Error('Требуется авторизация');

    const response = await axios.patch(`${API_BASE_URL}/${notificationId}`, {}, {
      headers: { Authorization: `Bearer ${token}` }
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: 'Ошибка при обновлении уведомления' };
  }
};