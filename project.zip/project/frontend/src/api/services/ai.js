import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export const analyzeProjectDescription = async (description, price) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Требуется авторизация');
    }

    const response = await axios.post(
      `${API_BASE_URL}/orders/analyze-description`,
      { description, price },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000
      }
    );
    
    console.log('Full response:', response);
    
    if (!response.data.success) {
      throw new Error(response.data.message || 'Ошибка анализа');
    }

    return {
      success: true,
      data: response.data.data
    };
  } catch (error) {
    console.error('Analysis error:', error);
    return {
      success: false, 
      message: error.response?.data?.message || 
              error.message || 
              'Ошибка при анализе описания'
    };
  }
};

export const analyzeDescription = analyzeProjectDescription;