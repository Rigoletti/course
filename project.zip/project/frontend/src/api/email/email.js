import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api/email';

export const verifyEmailCode = async (userId, code) => {
  try {
    const response = await axios.post(
      `${API_BASE_URL}/verify-email`,
      { code },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

export const resendVerificationEmail = async (userId) => {
  try {
    const response = await axios.post(
      `${API_BASE_URL}/resend-verification`,
      {},
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      }
    );
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};