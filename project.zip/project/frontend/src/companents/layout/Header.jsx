import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../../assets/img/logo_white.png';
import '../../assets/style/layout/Header.css';
import axios from 'axios';
import NotificationsDropdown from '../notifications/NotificationsDropdown';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Header = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState('user');
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const response = await axios.get('http://localhost:5000/api/auth/check-role', {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          setIsAuthenticated(true);
          setUserRole(response.data.role || 'user');
        } catch (error) {
          console.error('Ошибка проверки авторизации:', error);
          localStorage.removeItem('token');
        }
      }
    };

    checkAuth();
  }, []);

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:5000/api/auth/logout');
      localStorage.removeItem('token');
      setIsAuthenticated(false);
      setUserRole('user');
      navigate('/');
    } catch (error) {
      console.error('Ошибка при выходе:', error);
    }
  };

  return (
    <header style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)' }}>
      <nav className="navbar navbar-expand-lg navbar-dark container">
        <Link to="/" className="navbar-brand">
          <img src={logo} alt="логотип" className="img-fluid" style={{ height: '25px' }} />
        </Link>

        <button 
          className="navbar-toggler" 
          type="button" 
          data-bs-toggle="collapse" 
          data-bs-target="#navbarNavDropdown" 
          aria-controls="navbarNavDropdown" 
          aria-expanded="false" 
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNavDropdown">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <Link to="/post-project" className="nav-link literata-font">Подать заявку</Link>
            </li>
            <li className="nav-item">
              <Link to="/category" className="nav-link literata-font">Найти работу</Link>
            </li>
          </ul>

          <ul className="navbar-nav">
            {isAuthenticated ? (
              <>
                {userRole === 'admin' && (
                  <li className="admin nav-item">
                    <Link to="/admin" className="nav-link literata-font">Админ панель</Link>
                  </li>
                )}
                <li className="profile nav-item">
                  <Link to="/profile" className="nav-link literata-font">Профиль</Link>
                </li>
                <li className="nav-item notification-item">
                  <NotificationsDropdown />
                </li>
              </>
            ) : (
              <li className="nav-item">
                <Link to="/authorization" className="nav-link literata-font">Авторизация</Link>
              </li>
            )}
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;