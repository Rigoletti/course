import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Modal, Button, Form, Badge, Spinner, Alert, Card, ListGroup } from "react-bootstrap";
import { FaRobot, FaCheck, FaArrowRight, FaMoneyBillWave, FaCalendarAlt } from "react-icons/fa";
import { analyzeProjectDescription } from "../../api/services/ai";
import '../../assets/style/post_project/PostProject.css';

const PostProject = () => {
  const navigate = useNavigate();
  const [state, setState] = useState({
    step: 1,
    form: {
      title: "",
      description: "",
      price: "",
      daysLeft: 7,
      selectedSkills: [],
      selectedFeatures: []
    },
    aiData: null,
    loading: false,
    analyzing: false,
    error: null,
    showSuccess: false,
    originalDescription: ""
  });

  const analyzeDescription = async (description, userPrice) => {
    try {
      setState(prev => ({ ...prev, analyzing: true, error: null }));
      
      const response = await analyzeProjectDescription(description, userPrice);
      console.log('Full API response:', response);
      
      if (!response.success) {
        throw new Error(response.message || "Ошибка анализа данных");
      }
      
      return response;
    } catch (error) {
      console.error("AI analysis error:", error);
      throw error;
    } finally {
      setState(prev => ({ ...prev, analyzing: false }));
    }
  };

  const handleAnalyze = async (e) => {
    e.preventDefault();
    const { description, price } = state.form;

    if (!description || !price) {
      setState(prev => ({ ...prev, error: "Заполните обязательные поля" }));
      return;
    }

    try {
      const response = await analyzeDescription(description, price);
      
      if (response.success) {
        console.log('AI Data:', response.data);
        
        setState(prev => ({
          ...prev,
          step: 2,
          aiData: response.data,
          originalDescription: description,
          form: {
            ...prev.form,
            title: response.data.title || '',
            selectedSkills: response.data.skills?.slice(0, 3) || [],
            selectedFeatures: response.data.features?.slice(0, 2) || []
          }
        }));
      }
    } catch (err) {
      console.error('Error in handleAnalyze:', err);
      setState(prev => ({ 
        ...prev, 
        error: err.message || "Произошла ошибка при анализе. Пожалуйста, проверьте введенные данные и попробуйте снова."
      }));
    }
  };

  const updateDescriptionWithFeatures = () => {
    let updatedDescription = state.originalDescription;
    if (state.form.selectedFeatures.length > 0) {
      updatedDescription += "\n\nДополнительные функции:\n";
      updatedDescription += state.form.selectedFeatures.map(f => `- ${f}`).join("\n");
    }
    return updatedDescription;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const finalDescription = updateDescriptionWithFeatures();

      console.log("Отправка данных:", {
        title: state.form.title,
        description: finalDescription,
        price: state.form.price,
        daysLeft: state.form.daysLeft,
        skills: state.form.selectedSkills,
        features: state.form.selectedFeatures
      });

      setState(prev => ({ ...prev, showSuccess: true }));
    } catch (err) {
      setState(prev => ({ ...prev, error: err.message }));
    } finally {
      setState(prev => ({ ...prev, loading: false }));
    }
  };

  const toggleSkill = (skill) => {
    setState(prev => {
      const newSkills = prev.form.selectedSkills.includes(skill)
        ? prev.form.selectedSkills.filter(s => s !== skill)
        : [...prev.form.selectedSkills, skill];
      
      return {
        ...prev,
        form: { ...prev.form, selectedSkills: newSkills }
      };
    });
  };

  const toggleFeature = (feature) => {
    setState(prev => {
      const newFeatures = prev.form.selectedFeatures.includes(feature)
        ? prev.form.selectedFeatures.filter(f => f !== feature)
        : [...prev.form.selectedFeatures, feature];
      
      return {
        ...prev,
        form: { 
          ...prev.form, 
          selectedFeatures: newFeatures
        }
      };
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setState(prev => ({
      ...prev,
      form: { ...prev.form, [name]: value }
    }));
  };

  return (
    <div className="container mt-5">
      <div className="card shadow-lg">
        <div className="card-body p-5">
          <h2 className="mb-4 text-center">Создание заказа</h2>

          {state.error && (
            <Alert variant="danger" onClose={() => setState(prev => ({ ...prev, error: null }))} dismissible>
              {state.error}
            </Alert>
          )}

          {state.step === 1 ? (
            <form onSubmit={handleAnalyze}>
              <Form.Group className="mb-4">
                <Form.Label className="fw-bold">Описание проекта *</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={6}
                  name="description"
                  value={state.form.description}
                  onChange={handleInputChange}
                  required
                  className="modern-input"
                  placeholder="Опишите ваш проект максимально подробно..."
                />
              </Form.Group>

              <div className="row mb-4">
                <div className="col-md-6 mb-3">
                  <Form.Label className="fw-bold d-flex align-items-center">
                    <FaMoneyBillWave className="me-2 text-primary" />
                    Бюджет (₽) *
                  </Form.Label>
                  <div className="input-group">
                    <span className="input-group-text">₽</span>
                    <Form.Control
                      type="number"
                      name="price"
                      value={state.form.price}
                      onChange={handleInputChange}
                      min="100"
                      required
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <Form.Label className="fw-bold d-flex align-items-center">
                    <FaCalendarAlt className="me-2 text-primary" />
                    Срок (дни) *
                  </Form.Label>
                  <Form.Control
                    type="number"
                    name="daysLeft"
                    value={state.form.daysLeft}
                    onChange={handleInputChange}
                    min="1"
                    required
                  />
                </div>
              </div>

              <Button
                variant="primary"
                type="submit"
                disabled={state.analyzing}
                className="w-100 py-3"
              >
                {state.analyzing ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" />
                    Анализируем описание...
                  </>
                ) : (
                  <>
                    Дальше <FaArrowRight className="ms-2" />
                  </>
                )}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleSubmit}>
              <Card className="mb-4 border-primary">
                <Card.Header className="bg-primary text-white d-flex align-items-center">
                  <FaRobot className="me-2" />
                  Рекомендации от AI
                </Card.Header>
                <Card.Body>
                  <Form.Group className="mb-4">
                    <Form.Label className="fw-bold">Название проекта</Form.Label>
                    <Form.Control
                      type="text"
                      name="title"
                      value={state.form.title}
                      onChange={handleInputChange}
                    />
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <Form.Label className="fw-bold">Описание проекта</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={6}
                      value={updateDescriptionWithFeatures()}
                      onChange={(e) => setState(prev => ({
                        ...prev,
                        form: { ...prev.form, description: e.target.value }
                      }))}
                    />
                    <Form.Text className="text-muted">
                      Вы можете отредактировать описание, включая добавленные функции
                    </Form.Text>
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <Form.Label className="fw-bold d-flex align-items-center">
                      <FaMoneyBillWave className="me-2 text-primary" />
                      Бюджет
                    </Form.Label>
                    <div className="input-group">
                      <span className="input-group-text">₽</span>
                      <Form.Control
                        type="number"
                        value={state.form.price}
                        readOnly
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <Form.Label className="fw-bold d-flex align-items-center">
                      <FaRobot className="me-2 text-primary" />
                      Необходимые навыки
                    </Form.Label>
                    <div className="d-flex flex-wrap gap-2 mb-3">
                      {state.aiData?.skills?.map((skill, i) => (
                        <Badge
                          key={i}
                          pill
                          bg={state.form.selectedSkills.includes(skill) ? "primary" : "light"}
                          text={state.form.selectedSkills.includes(skill) ? "white" : "dark"}
                          className="cursor-pointer py-2 px-3"
                          onClick={() => toggleSkill(skill)}
                        >
                          {skill}
                          {state.form.selectedSkills.includes(skill) && <FaCheck className="ms-2" />}
                        </Badge>
                      ))}
                    </div>
                  </Form.Group>

                  <Form.Group>
                    <Form.Label className="fw-bold d-flex align-items-center">
                      <FaRobot className="me-2 text-primary" />
                      Дополнительные функции
                    </Form.Label>
                    <ListGroup className="mb-3">
                      {state.aiData?.features?.map((feature, i) => (
                        <ListGroup.Item key={i}>
                          <Form.Check
                            type="checkbox"
                            label={feature}
                            checked={state.form.selectedFeatures.includes(feature)}
                            onChange={() => toggleFeature(feature)}
                          />
                        </ListGroup.Item>
                      ))}
                    </ListGroup>
                  </Form.Group>
                </Card.Body>
              </Card>

              <div className="d-flex justify-content-between">
                <Button
                  variant="outline-secondary"
                  onClick={() => setState(prev => ({ ...prev, step: 1 }))}
                >
                  Назад
                </Button>
                <Button
                  variant="primary"
                  type="submit"
                  disabled={state.loading}
                >
                  {state.loading ? <Spinner size="sm" /> : "Создать заказ"}
                </Button>
              </div>
            </form>
          )}
        </div>
      </div>

      <Modal show={state.showSuccess} onHide={() => navigate("/profile")} centered>
        <Modal.Body className="text-center p-5">
          <div className="text-success mb-3" style={{ fontSize: "3rem" }}>
            <FaCheck />
          </div>
          <h4 className="mb-3">Заказ успешно создан!</h4>
          <p className="text-muted mb-4">
            Исполнители уже могут видеть ваш проект и предлагать свои услуги
          </p>
          <Button 
            variant="primary" 
            onClick={() => navigate("/profile")}
            size="lg"
          >
            Перейти в профиль
          </Button>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default PostProject;