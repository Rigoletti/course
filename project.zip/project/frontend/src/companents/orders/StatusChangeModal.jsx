import React from 'react';
import { Modal, Button } from 'react-bootstrap';

const StatusChangeModal = ({ show, onHide, onConfirm, currentStatus, newStatus }) => {
  const getStatusText = (status) => {
    switch (status) {
      case 'active': return 'Активен';
      case 'in_progress': return 'В работе';
      case 'completed': return 'Завершен';
      case 'canceled': return 'Отменен';
      default: return status;
    }
  };

  const getStatusChangeMessage = () => {
    if (newStatus === 'completed') {
      return 'Вы уверены, что хотите отметить заказ как завершенный?';
    } else if (newStatus === 'canceled') {
      return 'Вы уверены, что хотите отменить заказ?';
    }
    return `Вы уверены, что хотите изменить статус с "${getStatusText(currentStatus)}" на "${getStatusText(newStatus)}"?`;
  };

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>Подтверждение изменения статуса</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>{getStatusChangeMessage()}</p>
        {newStatus === 'completed' && (
          <div className="alert alert-info mt-3">
            После завершения заказа клиент сможет оставить отзыв о вашей работе.
          </div>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Отмена
        </Button>
        <Button variant="primary" onClick={onConfirm}>
          Подтвердить
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default StatusChangeModal;