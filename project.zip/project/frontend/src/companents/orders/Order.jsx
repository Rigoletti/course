import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchOrdersByCategory } from '../../api/services/orders';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import "../../assets/style/orders/Orders.css";

const Order = () => {
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [dateFilter, setDateFilter] = useState('new'); // 'new' or 'old'
  const [priceFilter, setPriceFilter] = useState('asc'); // 'asc' or 'desc'
  const [skillsFilter, setSkillsFilter] = useState('');
  const [hideCompleted, setHideCompleted] = useState(false); // Состояние для скрытия завершенных заказов
  const [searchQuery, setSearchQuery] = useState(''); // Состояние для поискового запроса

  useEffect(() => {
    const loadOrders = async () => {
      try {
        setLoading(true);
        const response = await fetchOrdersByCategory(categoryId, currentPage, 10);
        
        if (response.success) {
          setOrders(response.orders || []);
          setTotalPages(response.totalPages || 1);
          setError(null);
        } else {
          throw new Error(response.error || 'Не удалось загрузить заказы');
        }
      } catch (err) {
        console.error('Error:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadOrders();
  }, [categoryId, currentPage]);
  
  const filterOrders = (orders) => {
    let filteredOrders = orders.filter(order => {
      const matchesSkills = skillsFilter ? order.skills.some(skill => skill.toLowerCase().includes(skillsFilter.toLowerCase())) : true;
      const matchesStatus = hideCompleted ? order.status !== 'completed' : true; // Фильтрация по статусу
      const matchesSearch = order.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            order.description.toLowerCase().includes(searchQuery.toLowerCase()); // Фильтрация по поисковому запросу
      return matchesSkills && matchesStatus && matchesSearch;
    });

    // Сортировка по дате
    filteredOrders.sort((a, b) => {
      const orderDateA = new Date(a.createdAt);
      const orderDateB = new Date(b.createdAt);
      return dateFilter === 'new' ? orderDateB - orderDateA : orderDateA - orderDateB;
    });

    // Сортировка по цене
    filteredOrders.sort((a, b) => {
      return priceFilter === 'asc' ? a.price - b.price : b.price - a.price;
    });

    return filteredOrders;
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleOrderClick = (orderId) => {
    navigate(`/orders/${orderId}`);
  };

  const handleBack = () => {
    navigate(`/category`);
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'active':
        return 'Активен';
      case 'in_progress':
        return 'В работе';
      case 'completed':
        return 'Завершен';
      case 'canceled':
        return 'Отменен';
      default:
        return 'Неизвестный статус';
    }
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
        <div className="text-center">
          <div className="spinner-grow text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-3 text-muted">Загружаем заказы...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-5">
        <div className="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Ошибка!</strong> {error}
          <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <button onClick={handleBack} className="btn btn-outline-primary mt-3">
          <i className="bi bi-arrow-left me-2"></i>
          Вернуться назад
        </button>
      </div>
    );
  }

  const filteredOrders = filterOrders(orders);

  return (
    <div className="container py-4">
      <div className="row mb-3">
        <div className="col">
          <button 
            onClick={handleBack}
            className="btn btn-outline-secondary"
          >
            <i className="bi bi-arrow-left me-2"></i>
            Назад
          </button>
        </div>
      </div>

      <div className="row mb-4">
        <div className="col">
          <h2 className="fw-bold text-gradient mb-1">Доступные заказы</h2>
          <p className="text-muted">Выберите интересующий вас заказ</p>
        </div>
      </div>

      <div className="d-flex">
        <div className="filter-section me-4" style={{ width: '350px', minHeight: '400px' }}>
          <h5>Фильтры</h5>
          <div className="form-group">
            <label>Поиск:</label>
            <input 
              type="text" 
              value={searchQuery} 
              onChange={(e) => setSearchQuery(e.target.value)} 
              className="form-control mb-2" 
              placeholder="Поиск по названию или описанию" 
            />
          </div>
          <div className="form-group">
            <label>Фильтр по дате:</label>
            <select 
              className="form-select mb-2" 
              value={dateFilter} 
              onChange={(e) => setDateFilter(e.target.value)}
            >
              <option value="new">Новые</option>
              <option value="old">Старые</option>
            </select>
          </div>
          <div className="form-group">
            <label>Фильтр по цене:</label>
            <select 
              className="form-select mb-2" 
              value={priceFilter} 
              onChange={(e) => setPriceFilter(e.target.value)}
            >
              <option value="asc">По возрастанию</option>
              <option value="desc">По убыванию</option>
            </select>
          </div>
          <input 
            type="text" 
            value={skillsFilter} 
            onChange={(e) => setSkillsFilter(e.target.value)} 
            className="form-control mb-2" 
            placeholder="Фильтр по навыкам" 
          />
          <div className="form-check">
            <input 
              type="checkbox" 
              className="form-check-input" 
              id="hideCompleted" 
              checked={hideCompleted} 
              onChange={() => setHideCompleted(!hideCompleted)} 
            />
            <label className="form-check-label" htmlFor="hideCompleted">
              Скрыть завершенные заказы
            </label>
          </div>
        </div>

        <div className="flex-grow-1">
          {filteredOrders && filteredOrders.length > 0 ? (
            <div className="row g-4">
              {filteredOrders.map(order => (
                <div key={order._id} className="col-md-6 col-lg-4">
                  <div 
                    className={`card h-100 shadow-sm border-0 hover-shadow transition-all status-${order.status}`}
                    onClick={() => handleOrderClick(order._id)}
                    style={{ cursor: 'pointer' }}
                  >
                    <div className="card-body d-flex flex-column">
                      <div className="d-flex justify-content-between align-items-start mb-3">
                        <h5 className="card-title fw-bold text-truncate">{order.title}</h5>
                        <span className="badge bg-success bg-opacity-10 text-success fs-6">
                          {order.price?.toLocaleString()}₽
                        </span>
                      </div>
                      
                      <div className="mb-2">
                        <span className={`badge badge-status badge-status-${order.status}`}>
                          {getStatusText(order.status)}
                        </span>
                      </div>
                      
                      <p className="card-text text-muted flex-grow-1">
                        {order.description?.length > 100 
                          ? `${order.description.substring(0, 100)}...` 
                          : order.description}
                      </p>
                      
                      <div className="mt-3">
                        <div className="d-flex justify-content-between align-items-center">
                          <span className={`badge ${order.daysLeft > 3 ? 'bg-info' : 'bg-warning'} text-dark`}>
                            <i className="bi bi-clock me-1"></i>
                            {order.daysLeft} {order.daysLeft === 1 ? 'день' : order.daysLeft < 5 ? 'дня' : 'дней'} осталось
                          </span>
                          <button className="btn btn-sm btn-outline-primary">
                            Подробнее
                          </button>
                        </div>
                      </div>
                      
                      {order.skills?.length > 0 && (
                        <div className="mt-3 pt-2 border-top">
                          <div className="d-flex flex-wrap gap-1">
                            {order.skills.map((skill, i) => (
                              <span key={i} className="badge bg-light text-dark border">
                                <i className="bi bi-tag me-1"></i>
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="row">
              <div className="col">
                <div className="card shadow-sm border-0">
                  <div className="card-body text-center py-5">
                    <i className="bi bi-inbox text-muted" style={{ fontSize: '3rem' }}></i>
                    <h5 className="mt-3">В этой категории пока нет заказов</h5>
                    <p className="text-muted">Попробуйте проверить позже или посмотрите другие категории</p>
                    <button onClick={handleBack} className="btn btn-primary mt-3">
                      <i className="bi bi-arrow-left me-2"></i>
                      Вернуться назад
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {totalPages > 1 && (
        <div className="row mt-5">
          <div className="col">
            <nav aria-label="Page navigation">
              <ul className="pagination justify-content-center">
                <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handlePageChange(currentPage - 1)}
                    aria-label="Previous"
                  >
                    <i className="bi bi-chevron-left"></i>
                  </button>
                </li>
                
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNum;
                  if (totalPages <= 5) {
                    pageNum = i + 1;
                  } else if (currentPage <= 3) {
                    pageNum = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    pageNum = totalPages - 4 + i;
                  } else {
                    pageNum = currentPage - 2 + i;
                  }
                  
                  return (
                    <li key={pageNum} className={`page-item ${currentPage === pageNum ? 'active' : ''}`}>
                      <button 
                        className="page-link" 
                        onClick={() => handlePageChange(pageNum)}
                      >
                        {pageNum}
                      </button>
                    </li>
                  );
                })}
                
                <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handlePageChange(currentPage + 1)}
                    aria-label="Next"
                  >
                    <i className="bi bi-chevron-right"></i>
                  </button>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      )}
    </div>
  );
};

export default Order;