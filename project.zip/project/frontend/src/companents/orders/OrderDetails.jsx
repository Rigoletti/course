import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { fetchOrderById } from '../../api/services/orders';
import { createProposal } from '../../api/services/proposal';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ProposalModal from '../notifications/ProposalModal';
import Header from '../layout/Header';
import { Button, Modal, Form, Alert, Badge, Card, Tab, Tabs } from 'react-bootstrap';
import "../../assets/style/orders/OrderDetails.css";
import { 
  createReview, 
  getOrderReview,
  getUserReviews 
} from '../../api/review/review';
import Chat from "../chat/Chat";

const ReviewModal = ({ show, onHide, onSubmit, executorName }) => {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
      await onSubmit({
        rating,
        comment: comment.trim()
      });
    } catch (error) {
      toast.error(error.message || 'Ошибка при отправке отзыва');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>Оставить отзыв</Modal.Title>
      </Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <p className="mb-4">Оцените работу исполнителя <strong>{executorName}</strong></p>
          
          <Form.Group className="mb-4 text-center">
            <div className="rating-stars">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  className={`star-btn ${star <= rating ? 'active' : ''}`}
                  onClick={() => setRating(star)}
                  style={{
                    background: 'none',
                    border: 'none',
                    fontSize: '2rem',
                    color: star <= rating ? '#ffc107' : '#e4e5e9',
                    cursor: 'pointer',
                    padding: '0 5px'
                  }}
                >
                  ★
                </button>
              ))}
            </div>
            <div className="mt-2">
              <small className="text-muted">
                {rating === 1 && 'Ужасно'}
                {rating === 2 && 'Плохо'}
                {rating === 3 && 'Нормально'}
                {rating === 4 && 'Хорошо'}
                {rating === 5 && 'Отлично'}
              </small>
            </div>
          </Form.Group>
          
          <Form.Group className="mb-3">
            <Form.Label>Комментарий (необязательно)</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Расскажите о вашем опыте работы с исполнителем"
              maxLength={1000}
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={onHide} disabled={submitting}>
            Отмена
          </Button>
          <Button variant="primary" type="submit" disabled={submitting}>
            {submitting ? 'Отправка...' : 'Отправить отзыв'}
          </Button>
        </Modal.Footer>
      </Form>
    </Modal>
  );
};

const ReviewsSection = ({ userId }) => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setLoading(true);
        const response = await getUserReviews(userId);
        if (response.success) {
          setReviews(response.data);
        }
      } catch (error) {
        console.error('Ошибка при загрузке отзывов:', error);
      } finally {
        setLoading(false);
      }
    };

    if (userId) {
      fetchReviews();
    }
  }, [userId]);

  if (loading) {
    return (
      <div className="text-center py-3">
        <div className="spinner-border spinner-border-sm text-secondary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (reviews.length === 0) {
    return <p className="text-muted text-center py-3">Пока нет отзывов</p>;
  }

  return (
    <div className="mt-3">
      <h6>Отзывы о пользователе:</h6>
      <div className="reviews-container" style={{ maxHeight: '300px', overflowY: 'auto' }}>
        {reviews.map((review) => (
          <Card key={review._id} className="mb-2">
            <Card.Body>
              <div className="d-flex justify-content-between">
                <div className="d-flex align-items-center mb-2">
                  <div className="text-warning me-2">
                    {'★'.repeat(review.rating)}
                    {'☆'.repeat(5 - review.rating)}
                  </div>
                  <span className="fw-bold">{review.rating}.0</span>
                </div>
                <small className="text-muted">
                  {new Date(review.createdAt).toLocaleDateString('ru-RU')}
                </small>
              </div>
              {review.comment && <p className="mb-0">{review.comment}</p>}
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
};

const OrderDetails = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showProposalModal, setShowProposalModal] = useState(false);
  const [proposalSent, setProposalSent] = useState(false);
  const [hasActiveProposal, setHasActiveProposal] = useState(false);
  const [isCurrentUserAssigned, setIsCurrentUserAssigned] = useState(false);
  const [isOrderOwner, setIsOrderOwner] = useState(false);
  const [showCompletionModal, setShowCompletionModal] = useState(false);
  const [completionMessage, setCompletionMessage] = useState('');
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [existingReview, setExistingReview] = useState(null);
  const [showUserReviews, setShowUserReviews] = useState(false);
  const [userId, setUserId] = useState('');
  const [activeTab, setActiveTab] = useState('details');
  
  useEffect(() => {
    const loadOrder = async () => {
      try {
        setLoading(true);
        const response = await fetchOrderById(orderId);
        
        if (response.success) {
          setOrder(response.order);
          setHasActiveProposal(response.order.status !== 'active');

          const token = localStorage.getItem('token');
          if (token) {
            const userData = JSON.parse(atob(token.split('.')[1]));
            setUserId(userData.userId);
            setIsCurrentUserAssigned(userData.userId === response.order.assignedTo?._id.toString());
            setIsOrderOwner(userData.userId === response.order.createdBy?._id.toString());
          }
        } else {
          setError(response.message || 'Заказ не найден');
        }
      } catch (err) {
        console.error('Ошибка при загрузке заказа:', err);
        setError(err.message || 'Ошибка при загрузке заказа');
      } finally {
        setLoading(false);
      }
    };

    loadOrder();
  }, [orderId]);

  useEffect(() => {
    if (order?.status === 'completed') {
      const checkReview = async () => {
        try {
          const response = await getOrderReview(orderId);
          if (response.success && response.data) {
            setExistingReview(response.data);
          }
        } catch (error) {
          console.error('Error checking review:', error);
        }
      };
      
      checkReview();
    }
  }, [order?.status, orderId]);

  const handleSubmitReview = async (reviewData) => {
    try {
      const response = await createReview(orderId, reviewData);
      setExistingReview(response.data);
      setShowReviewModal(false);
      toast.success('Ваш отзыв успешно сохранен!');
      
      const orderResponse = await fetchOrderById(orderId);
      if (orderResponse.success) {
        setOrder(orderResponse.order);
      }
    } catch (error) {
      toast.error(error.message || 'Ошибка при сохранении отзыва');
    }
  };

  const handleBackToOrders = () => {
    if (order?.category?._id) {
      navigate(`/orders/category/${order.category._id}`);
    } else {
      navigate('/orders');
    }
  };

  const handleSendProposal = async (proposalData) => {
    try {
      await createProposal(orderId, proposalData);
      setProposalSent(true);
      setShowProposalModal(false);
      toast.success('Ваше предложение успешно отправлено!');
    } catch (error) {
      console.error('Error sending proposal:', error);
      toast.error(error.message || 'Ошибка при отправке предложения');
    }
  };

  const handleCompleteOrderClick = () => {
    setShowCompletionModal(true);
  };

  const confirmOrderCompletion = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('Требуется авторизация');
        return;
      }
  
      const response = await axios.put(
        `http://localhost:5000/api/orders/${orderId}/complete`,
        { 
          message: completionMessage,
          attachments: []
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (response.data.success) {
        setOrder(prev => ({
          ...prev,
          status: 'pending_completion',
          completionRequest: {
            requestedAt: new Date(),
            message: completionMessage
          }
        }));
        toast.success(response.data.message);
        setShowCompletionModal(false);
        setCompletionMessage('');
      }
    } catch (error) {
      console.error('Ошибка при завершении заказа:', error);
      toast.error(
        error.response?.data?.message || 
        error.message || 
        'Не удалось отправить запрос на завершение'
      );
    }
  };

  const handleCompletionResponse = async (accept) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('Требуется авторизация');
        return;
      }
  
      const response = await axios.put(
        `http://localhost:5000/api/orders/${orderId}/completion`,
        { accept },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      if (response.data.success) {
        setOrder(prev => ({
          ...prev,
          status: accept ? 'completed' : 'in_progress',
          completionRequest: accept ? undefined : prev.completionRequest
        }));
        toast.success(response.data.message);
      }
    } catch (error) {
      console.error('Ошибка при подтверждении завершения:', error);
      toast.error(
        error.response?.data?.message || 
        error.message || 
        'Ошибка при обработке подтверждения'
      );
    }
  };

  const formatDate = (dateString) => {
    try {
      if (!dateString) return 'дата неизвестна';
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return 'дата неизвестна';
      return new Intl.DateTimeFormat('ru-RU', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }).format(date);
    } catch (error) {
      console.error('Ошибка форматирования даты:', error);
      return 'дата неизвестна';
    }
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'active': return 'bg-success';
      case 'in_progress': return 'bg-warning text-dark';
      case 'completed': return 'bg-primary';
      case 'canceled': return 'bg-danger';
      case 'pending_completion': return 'bg-info text-dark';
      default: return 'bg-secondary';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'active': return 'Активен';
      case 'in_progress': return 'В работе';
      case 'completed': return 'Завершен';
      case 'canceled': return 'Отменен';
      case 'pending_completion': return 'Ожидает подтверждения';
      default: return 'Неизвестный статус';
    }
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
        <div className="text-center">
          <div className="spinner-grow text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-3 text-muted">Загружаем информацию о заказе...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-5">
        <div className="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Ошибка!</strong> {error}
          <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <button onClick={handleBackToOrders} className="btn btn-outline-primary mt-3">
          ← Вернуться назад
        </button>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="order-details-page">
        <Header />
        <ToastContainer position="top-right" autoClose={5000} />
        <div className="container py-5">
          <button 
            onClick={handleBackToOrders} 
            className="btn btn-outline-secondary mb-4 d-flex align-items-center gap-2"
          >
            <i className="bi bi-arrow-left"></i>
            Назад к заказам
          </button>
          <div className="card shadow-sm border-0">
            <div className="card-body text-center py-5">
              <i className="bi bi-exclamation-circle text-muted" style={{ fontSize: '3rem' }}></i>
              <h5 className="mt-3">Заказ не найден</h5>
              <p className="text-muted">Возможно, он был удален или перемещен</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const client = order.createdBy || {
    firstName: 'Неизвестно',
    lastName: '',
    createdAt: new Date().toISOString(),
    rating: 0,
    reviewsCount: 0
  };

  const executor = order.assignedTo || {
    firstName: 'Неизвестно',
    lastName: '',
    _id: null,
    rating: 0,
    reviewsCount: 0
  };

  return (
    <div className="order-details-page">
      <Header />
      <ToastContainer position="top-right" autoClose={5000} />
      
      <div className="container py-5">
        <button 
          onClick={handleBackToOrders} 
          className="btn btn-outline-secondary mb-4 d-flex align-items-center gap-2"
        >
          <i className="bi bi-arrow-left"></i>
          Назад к заказам
        </button>
        
        <div className="row g-4">
          <div className="col-lg-8">
            <div className={`card shadow-sm border-0 h-100 ${order.status !== 'active' ? 'bg-light' : ''}`}>
              <div className="card-body p-4">
                <div className="d-flex justify-content-between align-items-start mb-4">
                  <div>
                    <h1 className="fw-bold mb-3">{order.title}</h1>
                    <span className={`badge ${getStatusBadge(order.status)} mb-2`}>
                      {getStatusText(order.status)}
                    </span>
                  </div>
                  <div className="d-flex flex-column align-items-end">
                    <span className="badge bg-success bg-opacity-10 text-success fs-4 mb-2">
                      {order.price.toLocaleString()}₽
                    </span>
                    <span className="text-muted small">Бюджет</span>
                  </div>
                </div>
                
                {order.assignedTo && (
                  <div className="mb-4 p-3 bg-light rounded">
                    <h5 className="fw-bold mb-3">Исполнитель</h5>
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0">
                        {executor.avatar ? (
                          <img 
                            src={executor.avatar} 
                            alt={`${executor.firstName} ${executor.lastName}`}
                            className="rounded-circle"
                            width="50"
                            height="50"
                          />
                        ) : (
                          <div className="avatar bg-secondary rounded-circle d-flex align-items-center justify-content-center" style={{ width: '50px', height: '50px' }}>
                            <i className="bi bi-person text-white"></i>
                          </div>
                        )}
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6 className="mb-0 fw-bold">
                          {executor.firstName} {executor.lastName}
                        </h6>
                        <div className="d-flex align-items-center">
                          <div className="text-warning me-2">
                            {'★'.repeat(Math.round(executor.rating || 0))}
                            {'☆'.repeat(5 - Math.round(executor.rating || 0))}
                          </div>
                          <span className="small">{(executor.rating || 0).toFixed(1)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="mb-4">
                  <span className="badge bg-info text-dark me-2">
                    <i className="bi bi-calendar me-1"></i>
                    {formatDate(order.createdAt)}
                  </span>
                  {order.daysLeft && (
                    <span className={`badge ${order.daysLeft > 3 ? 'bg-warning' : 'bg-danger'} text-dark`}>
                      <i className="bi bi-clock me-1"></i>
                      Осталось {order.daysLeft} {order.daysLeft === 1 ? 'день' : order.daysLeft < 5 ? 'дня' : 'дней'}
                    </span>
                  )}
                </div>

                <Tabs
                  activeKey={activeTab}
                  onSelect={(k) => setActiveTab(k)}
                  className="mb-3"
                  id="order-tabs"
                >
                  <Tab eventKey="details" title="Детали заказа">
                    <div className="mt-3">
                      <h5 className="fw-bold mb-3">Описание заказа</h5>
                      <div className="bg-light p-3 rounded-2">
                        <p className="mb-0" style={{ whiteSpace: 'pre-line' }}>{order.description}</p>
                      </div>
                    </div>
                    
                    {order.skills?.length > 0 && (
                      <div className="mb-4">
                        <h5 className="fw-bold mb-3">Требуемые навыки</h5>
                        <div className="d-flex flex-wrap gap-2">
                          {order.skills.map((skill, index) => (
                            <span key={index} className="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-10">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </Tab>

                  {(isOrderOwner || isCurrentUserAssigned) && (
                    <Tab eventKey="chat" title="Чат">
                      <div className="mt-3">
                        <Chat orderId={orderId} userId={userId} />
                      </div>
                    </Tab>
                  )}
                </Tabs>
                
                <div className="d-grid gap-2 d-md-flex mt-4">
                  {!isOrderOwner && order.status === 'active' && (
                    <button 
                      className="btn btn-primary px-4"
                      onClick={() => setShowProposalModal(true)}
                      disabled={proposalSent || hasActiveProposal}
                    >
                      <i className="bi bi-envelope me-2"></i>
                      {proposalSent ? 'Предложение отправлено' : 
                       hasActiveProposal ? 'Заказ уже в работе' : 'Отправить предложение'}
                    </button>
                  )}
                  
                  {isCurrentUserAssigned && order.status === 'in_progress' && (
                    <button 
                      className="btn btn-success px-4"
                      onClick={handleCompleteOrderClick}
                    >
                      <i className="bi bi-check-circle me-2"></i>
                      Завершить заказ
                    </button>
                  )}
                  
                  {isOrderOwner && order.status === 'pending_completion' && (
                    <div className="d-flex gap-2">
                      <button 
                        className="btn btn-success px-4"
                        onClick={() => handleCompletionResponse(true)}
                      >
                        <i className="bi bi-check-circle me-2"></i>
                        Подтвердить завершение
                      </button>
                      <button 
                        className="btn btn-danger px-4"
                        onClick={() => handleCompletionResponse(false)}
                      >
                        <i className="bi bi-x-circle me-2"></i>
                        Отклонить
                      </button>
                    </div>
                  )}
                  
                  <button className="btn btn-outline-secondary px-4">
                    <i className="bi bi-bookmark me-2"></i>
                    Сохранить заказ
                  </button>
                </div>

                {isOrderOwner && order.status === 'completed' && (
                  <>
                    {existingReview ? (
                      <div className="mt-4 p-3 bg-light rounded">
                        <h5>Ваш отзыв:</h5>
                        <div className="d-flex align-items-center mb-2">
                          <div className="text-warning me-2">
                            {'★'.repeat(existingReview.rating)}
                            {'☆'.repeat(5 - existingReview.rating)}
                          </div>
                          <span className="fw-bold">{existingReview.rating}.0</span>
                        </div>
                        {existingReview.comment && (
                          <p className="mb-0">{existingReview.comment}</p>
                        )}
                      </div>
                    ) : (
                      <button 
                        className="btn btn-warning mt-3"
                        onClick={() => setShowReviewModal(true)}
                      >
                        <i className="bi bi-star-fill me-2"></i>
                        Оставить отзыв
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
          
          <div className="col-lg-4">
            <div className="card shadow-sm border-0 sticky-top" style={{ top: '20px' }}>
              <div className="card-body p-4">
                <h5 className="fw-bold mb-4">О {isOrderOwner ? 'исполнителе' : 'клиенте'}</h5>
                
                <div className="d-flex align-items-center mb-4">
                  <div className="flex-shrink-0">
                    {isOrderOwner ? (
                      executor.avatar ? (
                        <img 
                          src={executor.avatar} 
                          alt={`${executor.firstName} ${executor.lastName}`}
                          className="rounded-circle"
                          width="50"
                          height="50"
                          onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = '/default-avatar.png';
                          }}
                        />
                      ) : (
                        <div className="avatar bg-secondary rounded-circle d-flex align-items-center justify-content-center" style={{ width: '50px', height: '50px' }}>
                          <i className="bi bi-person text-white"></i>
                        </div>
                      )
                    ) : (
                      client.avatar ? (
                        <img 
                          src={client.avatar} 
                          alt={`${client.firstName} ${client.lastName}`}
                          className="rounded-circle"
                          width="50"
                          height="50"
                          onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = '/default-avatar.png';
                          }}
                        />
                      ) : (
                        <div className="avatar bg-secondary rounded-circle d-flex align-items-center justify-content-center" style={{ width: '50px', height: '50px' }}>
                          <i className="bi bi-person text-white"></i>
                        </div>
                      )
                    )}
                  </div>
                  <div className="flex-grow-1 ms-3">
                    <h6 className="mb-0 fw-bold">
                      {isOrderOwner ? `${executor.firstName} ${executor.lastName}` : `${client.firstName} ${client.lastName}`}
                    </h6>
                    <small className="text-muted">
                      Зарегистрирован {formatDate(isOrderOwner ? executor.createdAt : client.createdAt)}
                    </small>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="d-flex align-items-center mb-2">
                    <div className="text-warning me-2">
                      {'★'.repeat(Math.round(isOrderOwner ? executor.rating : client.rating || 0))}
                      {'☆'.repeat(5 - Math.round(isOrderOwner ? executor.rating : client.rating || 0))}
                    </div>
                    <span className="fw-bold">{(isOrderOwner ? executor.rating : client.rating || 0).toFixed(1)}</span>
                  </div>
                  <small className="text-muted">
                    {isOrderOwner ? executor.reviewsCount : client.reviewsCount || 0} 
                    {isOrderOwner ? 
                      (executor.reviewsCount === 1 ? ' отзыв' : 
                       executor.reviewsCount < 5 ? ' отзыва' : ' отзывов') :
                      (client.reviewsCount === 1 ? ' отзыв' : 
                       client.reviewsCount < 5 ? ' отзыва' : ' отзывов')}
                  </small>
                </div>
                
                <div className="border-top pt-3">
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <h6 className="fw-bold mb-0">Контактная информация</h6>
                    <Button 
                      variant="link" 
                      size="sm" 
                      onClick={() => setShowUserReviews(!showUserReviews)}
                    >
                      {showUserReviews ? 'Скрыть отзывы' : 'Показать отзывы'}
                    </Button>
                  </div>
                  
                  {showUserReviews && (
                    <ReviewsSection userId={isOrderOwner ? executor._id : client._id} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ProposalModal 
        show={showProposalModal}
        onHide={() => setShowProposalModal(false)}
        onSubmit={handleSendProposal}
        orderPrice={order?.price}
      />

      <Modal show={showCompletionModal} onHide={() => setShowCompletionModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Завершение заказа</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group className="mb-3">
            <Form.Label>Опишите выполненную работу *</Form.Label>
            <Form.Control
              as="textarea"
              rows={4}
              value={completionMessage}
              onChange={(e) => setCompletionMessage(e.target.value)}
              placeholder="Подробно опишите, что было сделано..."
              required
            />
          </Form.Group>
          <Alert variant="info">
            После отправки заказчик получит уведомление и должен будет подтвердить завершение заказа.
          </Alert>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowCompletionModal(false)}>
            Отмена
          </Button>
          <Button 
            variant="success" 
            onClick={confirmOrderCompletion}
            disabled={!completionMessage.trim()}
          >
            Отправить запрос
          </Button>
        </Modal.Footer>
      </Modal>

      <ReviewModal 
        show={showReviewModal}
        onHide={() => setShowReviewModal(false)}
        onSubmit={handleSubmitReview}
        executorName={`${executor.firstName} ${executor.lastName}`}
      />
    </div>
  );
};

export default OrderDetails;