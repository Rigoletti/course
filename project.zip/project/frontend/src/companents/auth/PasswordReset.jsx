import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import '../../assets/style/auth/PasswordReset.css';

const PasswordReset = () => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [userId, setUserId] = useState('');
  const [message, setMessage] = useState({ type: '', content: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();

   const handleRequestCode = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        'http://localhost:5000/api/email/request-password-reset', 
        { email },
        { withCredentials: true }
      );
      setUserId(response.data.userId);
      setMessage({ type: 'success', content: response.data.message });
      setStep(2);
    } catch (error) {
      console.error('Error requesting password reset:', error);
      setMessage({ 
        type: 'error', 
        content: error.response?.data?.message || 'Ошибка запроса сброса пароля' 
      });
    }
  };
 
  const handleVerifyCode = async (e) => {
    e.preventDefault();
    try {
      console.log('Verifying code:', code, 'for user:', userId); // Логирование
      
      const response = await axios.post(
        'http://localhost:5000/api/email/verify-password-reset-code', 
        { 
          userId: userId, 
          code: code 
        },
        { 
          withCredentials: true,
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );
      
      console.log('Verification response:', response.data); // Логирование
      setMessage({ type: 'success', content: 'Код подтверждён' });
      setStep(3);
    } catch (error) {
      console.error('Verification error details:', {
        message: error.message,
        response: error.response?.data,
        userId: userId,
        code: code
      });
      setMessage({ 
        type: 'error', 
        content: error.response?.data?.message || 'Ошибка проверки кода' 
      });
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setMessage({ type: 'error', content: 'Пароли не совпадают' });
      return;
    }

    try {
      await axios.post(
        'http://localhost:5000/api/email/reset-password', 
        { userId, newPassword },
        { withCredentials: true }
      );
      setMessage({ 
        type: 'success', 
        content: 'Пароль успешно изменён. Теперь вы можете войти с новым паролем.' 
      });
      setTimeout(() => navigate('/authorization'), 3000);
    } catch (error) {
      console.error('Error resetting password:', error);
      setMessage({ 
        type: 'error', 
        content: error.response?.data?.message || 'Ошибка сброса пароля' 
      });
    }
  };

  return (
    <div className='password-reset-page'>
    <div className="password-reset-container">
      <div className="password-reset-form">
        <h2>Восстановление пароля</h2>
        
        {message.content && (
          <div className={`password-reset-message ${message.type}`}>
            {message.content}
          </div>
        )}

        {step === 1 && (
          <form onSubmit={handleRequestCode}>
            <p>Введите email, указанный при регистрации</p>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Ваш email"
              required
            />
            <button type="submit">Отправить код</button>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={handleVerifyCode}>
            <p>Введите код, отправленный на {email}</p>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="6-значный код"
              required
            />
            <button type="submit">Подтвердить код</button>
            <button 
              type="button" 
              className="resend-code"
              onClick={() => handleRequestCode({ preventDefault: () => {} })}
            >
              Отправить код повторно
            </button>
          </form>
        )}

        {step === 3 && (
          <form onSubmit={handleResetPassword}>
            <p>Введите новый пароль</p>
            <div className="password-input-container">
              <input
                type={showPassword ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Новый пароль"
                required
              />
              <span 
                className="password-toggle-icon"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </span>
            </div>
            <div className="password-input-container">
              <input
                type={showConfirmPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Подтвердите пароль"
                required
              />
              <span 
                className="password-toggle-icon"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
              </span>
            </div>
            <button type="submit">Изменить пароль</button>
          </form>
        )}

        <div className="back-to-login">
          <button onClick={() => navigate('/authorization')}>Вернуться к входу</button>
        </div>
      </div>
    </div>
    </div>
  );
};

export default PasswordReset;