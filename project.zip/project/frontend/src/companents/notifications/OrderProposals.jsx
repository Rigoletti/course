import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getOrderProposals, updateProposalStatus } from '../../api/services/proposal';
import { fetchOrderById } from '../../api/services/orders';
import { 
  Table, 
  Button, 
  Badge, 
  Modal, 
  Spinner,
  Card,
  Container,
  Image
} from 'react-bootstrap';
import UserProfileModal from './UserProfileModal';
import { toast } from 'react-toastify';
import styled from 'styled-components';

const StyledContainer = styled(Container)`
  padding: 24px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.03);
`;

const ProposalMessage = styled.div`
  max-width: 300px;
  white-space: pre-line;
  word-wrap: break-word;
  padding: 8px 0;
  color: #444;
`;

const EmptyState = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px 0;
  text-align: center;
  
  .icon {
    font-size: 48px;
    color: #bfbfbf;
    margin-bottom: 16px;
  }
  
  h4 {
    color: #595959;
    margin-bottom: 8px;
  }
  
  p {
    color: #8c8c8c;
    margin: 0;
  }
`;

const OrderProposals = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [proposals, setProposals] = useState([]);
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profileUser, setProfileUser] = useState(null);
  const [showDecisionModal, setShowDecisionModal] = useState(false);
  const [decision, setDecision] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const orderRes = await fetchOrderById(orderId);
        if (!orderRes.success) throw new Error('Order not found');
        
        const proposalsRes = await getOrderProposals(orderId);
        setProposals(proposalsRes.data);
        setOrder(orderRes.order);
      } catch (error) {
        toast.error('Не удалось загрузить предложения');
      } finally {
        setLoading(false);
      }
    };
  
    loadData();
  }, [orderId]);
  
  const handleViewProfile = (user) => {
    setProfileUser(user);
    setShowProfileModal(true);
  };

  const handleMakeDecision = (proposal, status) => {
    setSelectedProposal(proposal);
    setDecision(status);
    setShowDecisionModal(true);
  };

  const confirmDecision = async () => {
    try {
      await updateProposalStatus(selectedProposal._id, decision);
      setProposals(proposals.map(p => 
        p._id === selectedProposal._id ? { ...p, status: decision } : p
      ));
      toast.success(`Предложение ${decision === 'accepted' ? 'принято' : 'отклонено'}`);
    } catch (error) {
      toast.error('Ошибка при обновлении статуса');
    } finally {
      setShowDecisionModal(false);
    }
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  return (
    <StyledContainer>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>
          Предложения по заказу: <strong>{order?.title}</strong>
        </h2>
        <Button variant="outline-secondary" onClick={() => navigate(`/orders/${orderId}`)}>
          ← Назад к заказу
        </Button>
      </div>

      {proposals.length > 0 ? (
        <Card>
          <Table striped bordered hover responsive>
            <thead>
              <tr>
                <th>Исполнитель</th>
                <th>Сообщение</th>
                <th>Цена</th>
                <th>Срок</th>
                <th>Статус</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              {proposals.map(proposal => (
                <tr key={proposal._id}>
                  <td>
                    <div 
                      className="d-flex align-items-center text-primary" 
                      style={{ cursor: 'pointer' }}
                      onClick={() => handleViewProfile(proposal.sender)}
                    >
                     {proposal.sender.avatar ? (
  <Image 
    src={proposal.sender.avatar} 
    alt={proposal.sender.firstName} 
    roundedCircle 
    className="me-2" 
    width={40}
    height={40}
    onError={(e) => {
      e.target.onerror = null;
      e.target.src = '/default-avatar.png';
    }}
  />
) : (
  <div className="bg-secondary rounded-circle d-flex align-items-center justify-content-center me-2" style={{ width: '40px', height: '40px' }}>
    <span className="text-white">👤</span>
  </div>
)}
                      {proposal.sender.firstName} {proposal.sender.lastName}
                    </div>
                  </td>
                  <td>
                    <ProposalMessage>
                      {proposal.message}
                    </ProposalMessage>
                  </td>
                  <td>{proposal.price ? `${proposal.price}₽` : 'Не указана'}</td>
                  <td>{proposal.daysToComplete || 'Не указан'}</td>
                  <td>
                    <Badge 
                      bg={
                        proposal.status === 'accepted' ? 'success' : 
                        proposal.status === 'rejected' ? 'danger' : 'warning'
                      }
                    >
                      {
                        proposal.status === 'accepted' ? 'Принято' : 
                        proposal.status === 'rejected' ? 'Отклонено' : 'На рассмотрении'
                      }
                    </Badge>
                  </td>
                  <td>
                    {proposal.status === 'pending' && (
                      <div className="d-flex gap-2">
                        <Button 
                          variant="outline-success" 
                          size="sm"
                          onClick={() => handleMakeDecision(proposal, 'accepted')}
                        >
                          ✓ Принять
                        </Button>
                        <Button 
                          variant="outline-danger" 
                          size="sm"
                          onClick={() => handleMakeDecision(proposal, 'rejected')}
                        >
                          ✕ Отклонить
                        </Button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card>
      ) : (
        <EmptyState>
          <div className="icon">📭</div>
          <h4>Нет предложений по этому заказу</h4>
          <p>Когда появятся предложения, они отобразятся здесь</p>
        </EmptyState>
      )}

      <UserProfileModal
        show={showProfileModal}
        onHide={() => setShowProfileModal(false)}
        user={profileUser}
      />

      <Modal show={showDecisionModal} onHide={() => setShowDecisionModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Подтвердите действие</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="alert alert-warning">
            <div className="d-flex align-items-center">
              <span className="me-2">⚠️</span>
              <span>
                Вы уверены, что хотите {decision === 'accepted' ? 'принять' : 'отклонить'} предложение от{' '}
                <strong>{selectedProposal?.sender?.firstName} {selectedProposal?.sender?.lastName}</strong>?
              </span>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDecisionModal(false)}>
            Отмена
          </Button>
          <Button 
            variant={decision === 'accepted' ? 'success' : 'danger'} 
            onClick={confirmDecision}
          >
            {decision === 'accepted' ? 'Принять' : 'Отклонить'}
          </Button>
        </Modal.Footer>
      </Modal>
    </StyledContainer>
  );
};

export default OrderProposals;