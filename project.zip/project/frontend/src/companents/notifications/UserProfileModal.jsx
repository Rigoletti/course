import React from 'react';
import { Modal, Button, Badge } from 'react-bootstrap';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

const UserProfileModal = ({ show, onHide, user }) => {
  if (!user) return null;

  const formatDate = (dateString) => {
    try {
      if (!dateString) return 'Дата не указана';
      
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return 'Некорректная дата';
      
      return format(date, 'dd MMMM yyyy', { locale: ru });
    } catch (error) {
      console.error('Ошибка форматирования даты:', error);
      return 'Ошибка даты';
    }
  };

  return (
    <Modal show={show} onHide={onHide} centered size="lg">
      <Modal.Header closeButton>
        <Modal.Title>Профиль пользователя</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="row">
          <div className="col-md-4 text-center">
            {user.avatar ? (
              <img 
                src={user.avatar} 
                alt={`${user.firstName} ${user.lastName}`} 
                className="rounded-circle img-thumbnail mb-3" 
                style={{ width: '150px', height: '150px', objectFit: 'cover' }}
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = '/default-avatar.png';
                }}
              />
            ) : (
              <div className="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-3 mx-auto" style={{ width: '150px', height: '150px' }}>
                <i className="bi bi-person text-white" style={{ fontSize: '4rem' }}></i>
              </div>
            )}
            
            <h4>{user.firstName} {user.lastName}</h4>
            <p className="text-muted">{user.username}</p>
            
            <div className="d-flex justify-content-center gap-2 mb-3">
              <Button variant="primary" size="sm">
                <i className="bi bi-envelope me-1"></i> Написать
              </Button>
            </div>
          </div>
          
          <div className="col-md-8">
            <div className="card mb-3">
              <div className="card-body">
                <h5 className="card-title">Информация</h5>
                <ul className="list-unstyled">
                  <li className="mb-2">
                    <strong>Email:</strong> {user.email || 'Не указан'}
                  </li>
                  <li className="mb-2">
                    <strong>Дата регистрации:</strong> {formatDate(user.createdAt)}
                  </li>
                  {/* Остальной код остается без изменений */}
                </ul>
              </div>
            </div>
            {/* Остальной код остается без изменений */}
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Закрыть
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default UserProfileModal;