import React, { useState, useEffect } from 'react';
import { Badge, Dropdown, ListGroup } from 'react-bootstrap';
import { getNotifications, markAsRead, markNotificationAsRead } from '../../api/services/notification';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { io } from 'socket.io-client';
import '../../assets/style/notifications/NotificationsDropdown.css';

const socket = io('http://localhost:5000', {
  withCredentials: true,
  autoConnect: false
});

const NotificationsDropdown = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const checkAuth = () => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/authorization');
      return false;
    }
    return true;
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      // Подключаемся к WebSocket только если есть токен
      socket.auth = { token };
      socket.connect();

      // Подписываемся на новые уведомления
      socket.on('newNotification', (notification) => {
        setNotifications(prev => [notification, ...prev]);
        setUnreadCount(prev => prev + 1);
      });

      // Загружаем существующие уведомления
      fetchNotifications();
    }

    return () => {
      socket.off('newNotification');
      socket.disconnect();
    };
  }, []);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const response = await getNotifications();
      setNotifications(response.data);
      setUnreadCount(response.data.filter(n => !n.isRead).length);
    } catch (error) {
      if (error.message === 'Требуется авторизация') {
        navigate('/authorization');
      } else {
        toast.error('Ошибка загрузки уведомлений');
      }
    } finally {
      setLoading(false);
    }
  };

  // Остальные функции остаются без изменений
  const handleMarkAsRead = async () => {
    try {
      await markAsRead();
      setUnreadCount(0);
      setNotifications(notifications.map(n => ({ ...n, isRead: true })));
      toast.success('Все уведомления прочитаны');
    } catch (error) {
      toast.error('Ошибка при обновлении уведомлений');
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'proposal':
        return 'bi bi-envelope';
      case 'statusChange':
        return 'bi bi-arrow-repeat';
      case 'completionRequest':
        return 'bi bi-check-circle';
      case 'orderCompleted':
        return 'bi bi-check2-circle text-success';
      case 'completionRejected':
        return 'bi bi-x-circle text-danger';
      default:
        return 'bi bi-bell';
    }
  };

  const formatNotificationMessage = (notification) => {
    if (notification.type === 'orderCompleted') {
      return `Ваш заказ "${notification.order?.title || 'неизвестный заказ'}" подтвержден как выполненный!`;
    } else if (notification.type === 'completionRejected') {
      return `Завершение заказа "${notification.order?.title || 'неизвестный заказ'}" отклонено заказчиком`;
    } else if (notification.type === 'completionRequest') {
      return `Исполнитель запросил завершение заказа "${notification.order?.title || 'неизвестный заказ'}"`;
    } else if (notification.type === 'proposal') {
      return `Новое предложение по вашему заказу "${notification.order?.title || 'неизвестный заказ'}"`;
    }
    return notification.message;
  };
  
  const handleNotificationClick = async (notification) => {
    try {
      if (!notification.isRead) {
        await markNotificationAsRead(notification._id);
        setNotifications(notifications.map(n => 
          n._id === notification._id ? { ...n, isRead: true } : n
        ));
        setUnreadCount(prev => prev - 1);
      }

      if (notification.type === 'proposal' || notification.type === 'statusChange') {
        if (notification.order?._id) {
          window.location.href = `/orders/${notification.order._id}/proposals`;
        } else {
          toast.error('Заказ не найден');
        }
      }
      if (notification.type === 'completionRequest') {
        window.location.href = `/orders/${notification.order._id}`;
      }
      if (notification.type === 'orderCompleted' || notification.type === 'completionRejected') {
        window.location.href = `/orders/${notification.order._id}`;
      }
    } catch (error) {
      if (error.message === 'Требуется авторизация') {
        navigate('/authorization');
      } else {
        toast.error('Ошибка при обработке уведомления');
      }
    }
  };


  return (
    <Dropdown align="end" onToggle={(isOpen) => isOpen && checkAuth() && fetchNotifications()}>
      <Dropdown.Toggle
        variant="dark"
        className="position-relative p-2 border-0"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          color: 'white',
        }}
      >
        <i className="bi bi-bell fs-5"></i>
        {unreadCount > 0 && (
          <Badge pill bg="danger" className="position-absolute top-0 start-100 translate-middle">
            {unreadCount}
          </Badge>
        )}
      </Dropdown.Toggle>

      <Dropdown.Menu className="p-0" style={{ 
          minWidth: '350px',
          backgroundColor: '#2a2a2a', 
          color: '#e0e0e0', 
          zIndex: 1050,
          border: '1px solid #444'
        }}>
         <div className="d-flex justify-content-between align-items-center p-3 border-bottom" style={{ borderColor: '#444' }}>
          <h6 className="mb-0" style={{ color: '#fff' }}>Уведомления</h6>
          <button 
            className="btn btn-sm btn-link"
            onClick={handleMarkAsRead}
            disabled={unreadCount === 0}
            style={{ color: unreadCount === 0 ? '#666' : '#4dabf7' }}
          >
            Прочитать все
          </button>
        </div>

        {loading ? (
          <div className="text-center p-3">
            <div className="spinner-border spinner-border-sm text-light" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center p-3" style={{ color: '#aaa' }}>
            Нет новых уведомлений
          </div>
        ) : (
          <ListGroup variant="flush" style={{ maxHeight: '400px', overflowY: 'auto' }}>
            {notifications.map((notification) => (
              <ListGroup.Item 
                key={notification._id}
                action
                onClick={() => handleNotificationClick(notification)}
                style={{ 
                  backgroundColor: !notification.isRead ? 'rgba(0, 119, 255, 0.1)' : 'inherit',
                  color: '#e0e0e0',
                  borderColor: '#444',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
              >
                <div className="d-flex align-items-start">
                  <div className="flex-shrink-0 me-2">
                    {notification.sender?.avatar ? (
                      <img 
                        src={notification.sender.avatar} 
                        alt={notification.sender.firstName} 
                        className="rounded-circle" 
                        width="40" 
                        height="40"
                      />
                    ) : (
                      <div className="rounded-circle d-flex align-items-center justify-content-center" 
                           style={{ 
                             width: '40px', 
                             height: '40px',
                             backgroundColor: notification.type === 'proposalAccepted' ? 'rgba(40, 167, 69, 0.2)' :
                                             notification.type === 'proposalRejected' ? 'rgba(220, 53, 69, 0.2)' : '#6c757d'
                           }}>
                        <i className={`${getNotificationIcon(notification.type)} fs-5`}></i>
                      </div>
                    )}
                  </div>
                  <div className="flex-grow-1">
                    <div className="d-flex justify-content-between">
                      <strong>
                        {notification.sender?.firstName 
                          ? `${notification.sender.firstName} ${notification.sender.lastName || ''}`
                          : 'Системное уведомление'}
                      </strong>
                      <small className="text-muted">
                        {new Date(notification.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </small>
                    </div>
                    <p className="mb-0">{formatNotificationMessage(notification)}</p>
                    {notification.order?.title && (
                      <small className="text-muted">Заказ: {notification.order.title}</small>
                    )}
                  </div>
                </div>
              </ListGroup.Item>
            ))}
          </ListGroup>
        )}
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default NotificationsDropdown;