import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import { Modal, Button, Form, Carousel, Toast } from "react-bootstrap";
import {
  FaWallet,
  FaTasks,
  FaStar,
  FaEdit,
  FaKey,
  FaSignOutAlt,
  FaQuoteLeft,
  FaUser,
  FaCheck,
  FaEnvelope,
  FaUpload, 
} from "react-icons/fa";
import { motion, AnimatePresence } from "framer-motion";
import { useFormik } from "formik";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { profileSchema } from "../../utils/validation";
import styles from "../../assets/style/profile/ProfileSection.module.css";
import { verifyEmailCode, resendVerificationEmail } from "../../api/email/email";

const ProfileSection = () => {
  const [user, setUser] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [previewAvatar, setPreviewAvatar] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmNewPassword: "",
  });
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");
  const [showVerificationForm, setShowVerificationForm] = useState(false);
  const [verificationMessage, setVerificationMessage] = useState("");
  const [verificationError, setVerificationError] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const getToken = () => {
    return localStorage.getItem("token");
  };

  const fetchProfile = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const token = getToken();
      if (!token) throw new Error("Требуется авторизация");
      const profileResponse = await axios.get("http://localhost:5000/api/profile", {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
      const userData = profileResponse.data.user;
      if (!userData) throw new Error("Данные пользователя не получены");
      setUser(userData);
      setPreviewAvatar(userData.avatar || getDefaultAvatar(userData));
      setShowVerificationForm(!userData.emailVerified);
      const reviewsResponse = await axios.get(
        `http://localhost:5000/api/users/${userData.id}/reviews`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setReviews(reviewsResponse.data.data || []);
    } catch (err) {
      setError(err.message);
      toast.error("Требуется авторизация");
      navigate("/login");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [navigate, location.search]);

  const formik = useFormik({
    initialValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      bio: user?.bio || "",
      avatar: null,
    },
    validationSchema: profileSchema,
    enableReinitialize: true,
    onSubmit: async (values) => {
      try {
        const token = getToken();
        const formData = new FormData();
        formData.append("firstName", values.firstName);
        formData.append("lastName", values.lastName);
        formData.append("bio", values.bio);
        
        if (values.avatar) {
          formData.append("avatar", values.avatar); 
        }
    
        const response = await axios.put(
          "http://localhost:5000/api/profile",
          formData,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "multipart/form-data",
            },
          }
        );
    
        setUser(response.data.user);
        if (response.data.user.avatar) {
          setPreviewAvatar(response.data.user.avatar); // Обновляем превью аватарки
        }
        setIsEditing(false);
        toast.success("Профиль успешно обновлен!");
      } catch (err) {
        console.error("Ошибка обновления профиля:", err);
        toast.error(err.response?.data?.message || "Не удалось обновить профиль");
      }
    },
  });

  const [passwordErrors, setPasswordErrors] = useState({
    currentPassword: "",
    newPassword: "",
    confirmNewPassword: "",
    general: "",
  });

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setIsChangingPassword(true);
    setPasswordErrors({
      currentPassword: "",
      newPassword: "",
      confirmNewPassword: "",
      general: "",
    });
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("Требуется авторизация");
      }
      let hasError = false;
      const newErrors = {
        currentPassword: "",
        newPassword: "",
        confirmNewPassword: "",
        general: "",
      };
      if (!passwordData.currentPassword) {
        newErrors.currentPassword = "Введите текущий пароль";
        hasError = true;
      }
      if (!passwordData.newPassword) {
        newErrors.newPassword = "Введите новый пароль";
        hasError = true;
      } else if (!/(?=.*\d)(?=.*[A-Z]).{8,}/.test(passwordData.newPassword)) {
        newErrors.newPassword = "Пароль должен содержать 8+ символов, цифру и заглавную букву";
        hasError = true;
      }
      if (!passwordData.confirmNewPassword) {
        newErrors.confirmNewPassword = "Подтвердите новый пароль";
        hasError = true;
      } else if (passwordData.newPassword !== passwordData.confirmNewPassword) {
        newErrors.confirmNewPassword = "Пароли не совпадают";
        hasError = true;
      }
      if (hasError) {
        setPasswordErrors(newErrors);
        return;
      }
      const response = await axios.post(
        "http://localhost:5000/api/auth/change-password",
        {
          currentPassword: passwordData.currentPassword,
          newPassword: passwordData.newPassword,
          confirmNewPassword: passwordData.confirmNewPassword,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );
      toast.success(response.data.message || "Пароль успешно изменён");
      setShowPasswordModal(false);
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmNewPassword: "",
      });
    } catch (error) {
      console.error("Ошибка смены пароля:", error);
      if (error.response?.data?.message) {
        if (error.response.data.message.includes("Текущий пароль неверен")) {
          setPasswordErrors((prev) => ({
            ...prev,
            currentPassword: error.response.data.message,
          }));
        } else {
          setPasswordErrors((prev) => ({
            ...prev,
            general: error.response.data.message,
          }));
        }
      } else {
        setPasswordErrors((prev) => ({
          ...prev,
          general: error.message || "Не удалось изменить пароль",
        }));
      }
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleVerifyEmail = async () => {
    try {
      setIsVerifying(true);
      setVerificationError("");
      setVerificationMessage("");

      const token = getToken();
      const response = await axios.post(
        "http://localhost:5000/api/email/verify-email",
        { code: verificationCode },
        {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        }
      );

      setVerificationMessage("Email подтверждён!");
      setUser((prev) => ({ ...prev, emailVerified: true }));
      setTimeout(() => setShowVerificationForm(false), 2000);
      await fetchProfile();
    } catch (error) {
      console.error("Ошибка подтверждения email:", error);
      setVerificationError(error.response?.data?.message || error.message);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleResendCode = async () => {
    try {
      await resendVerificationEmail(user.id);
      setVerificationMessage("Новый код отправлен!");
    } catch (error) {
      setVerificationError(error.message);
    }
  };

  const handleLogout = async () => {
    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/logout",
        {},
        {
          withCredentials: true,
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (response.data.success) {
        localStorage.removeItem("token");
        window.location.href = "/authorization";
      } else {
        toast.error("Не удалось выйти");
      }
    } catch (err) {
      console.error("Ошибка при выходе:", err);
      toast.error("Не удалось выйти");
      localStorage.removeItem("token");
      window.location.href = "/authorization";
    }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
  
    const validTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!validTypes.includes(file.type)) {
      toast.error("Недопустимый формат изображения");
      return;
    }
  
    formik.setFieldValue("avatar", file);
    setPreviewAvatar(URL.createObjectURL(file)); // Показываем превью нового аватара
  };

  const getDefaultAvatar = (user) => {
    const name = user ? `${user.firstName}+${user.lastName}` : "Пользователь";
    return `https://ui-avatars.com/api/?name=${name}&background=random&size=150`;
  };

  if (isLoading) {
    return <div className="spinner-border text-primary" role="status"></div>;
  }
  if (error || !user) {
    return (
      <div className="alert alert-danger">
        <p>{error || "Не удалось загрузить профиль"}</p>
        <button className="btn btn-primary" onClick={() => navigate("/login")}>
          Войти
        </button>
      </div>
    );
  }

  return (
    <div className={styles.profileContainer}>
      <div className={styles.profileHeader}>
        <div className={styles.profileAvatar}>
          <img
            src={previewAvatar}
            alt="Аватар"
            onError={(e) => (e.target.src = getDefaultAvatar(user))}
          />
          {isEditing && (
            <label className={styles.avatarUpload}>
              <FaUpload />
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                style={{ display: "none" }}
              />
            </label>
          )}
        </div>
        <div className={styles.profileInfo}>
          {isEditing ? (
            <>
              <Form.Control
                name="firstName"
                value={formik.values.firstName}
                onChange={formik.handleChange}
                className="mb-2"
              />
              <Form.Control
                name="lastName"
                value={formik.values.lastName}
                onChange={formik.handleChange}
              />
            </>
          ) : (
            <h1 className={styles.profileName}>
              {user.firstName} {user.lastName}
              {user.emailVerified && (
                <span className={styles.verifiedBadge}>
                  <FaCheck />
                </span>
              )}
            </h1>
          )}
          <p className={styles.profileMeta}>
            Участник с{" "}
            {new Date(user.createdAt).toLocaleDateString("ru-RU")}
          </p>
        </div>
      </div>
      <div className={styles.profileContent}>
        <div className={styles.profileDescription}>
          <h2>О себе</h2>
          {isEditing ? (
            <Form.Control
              as="textarea"
              name="bio"
              value={formik.values.bio}
              onChange={formik.handleChange}
              rows={3}
            />
          ) : (
            <p>{user.bio || "Информация отсутствует."}</p>
          )}
        </div>
        <div className={styles.profileStats}>
          {[
            { icon: <FaWallet />, value: user.balance || 0, label: "Баланс" },
            {
              icon: <FaTasks />,
              value: user.completedOrders || 0,
              label: "Заказы",
            },
            {
              icon: <FaStar />,
              value: user.rating?.toFixed(1) || "0.0",
              label: "Рейтинг",
            },
            { icon: <FaStar />, value: reviews.length, label: "Отзывы" },
          ].map((stat, index) => (
            <div key={index} className={styles.statItem}>
              <div className={styles.statIcon}>{stat.icon}</div>
              <div className={styles.statValue}>{stat.value}</div>
              <div className={styles.statLabel}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
      <div className={styles.profileReviews}>
        <h2>Отзывы</h2>
        {reviews.length > 0 ? (
          <Carousel>
            {reviews.map((review, index) => (
              <Carousel.Item key={index}>
                <div className={styles.reviewCard}>
                  <div className={styles.reviewHeader}>
                    <div className={styles.reviewerAvatar}>
                      {review.reviewer?.avatar ? (
                        <img src={review.reviewer.avatar} alt="Аватар" />
                      ) : (
                        <FaUser />
                      )}
                    </div>
                    <div className={styles.reviewerInfo}>
                      <h4>{review.reviewer?.firstName || "Аноним"}</h4>
                      <div className={styles.reviewRating}>
                        {[1, 2, 3, 4, 5].map((star) => (
                          <FaStar
                            key={star}
                            className={
                              star <= review.rating
                                ? styles.starFilled
                                : styles.starEmpty
                            }
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className={styles.reviewContent}>
                    <FaQuoteLeft />
                    <p>{review.comment || "Без комментария"}</p>
                  </div>
                </div>
              </Carousel.Item>
            ))}
          </Carousel>
        ) : (
          <p>Пока нет отзывов</p>
        )}
      </div>
      <div className={styles.profileActions}>
        <Button
          variant="primary"
          onClick={isEditing ? formik.handleSubmit : () => setIsEditing(true)}
        >
          <FaEdit /> {isEditing ? "Сохранить" : "Редактировать"}
        </Button>
        <Button
          variant="secondary"
          onClick={() => setShowPasswordModal(true)}
        >
          <FaKey /> Сменить пароль
        </Button>
        <Button variant="danger" onClick={handleLogout}>
          <FaSignOutAlt /> Выйти
        </Button>
      </div>
      <Modal show={showPasswordModal} onHide={() => setShowPasswordModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Смена пароля</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {passwordErrors.general && (
            <div className="alert alert-danger">{passwordErrors.general}</div>
          )}
          <Form onSubmit={handlePasswordChange}>
            <Form.Group className="mb-3">
              <Form.Label>Текущий пароль</Form.Label>
              <Form.Control
                type="password"
                value={passwordData.currentPassword}
                onChange={(e) =>
                  setPasswordData({
                    ...passwordData,
                    currentPassword: e.target.value,
                  })
                }
                isInvalid={!!passwordErrors.currentPassword}
              />
              <Form.Control.Feedback type="invalid">
                {passwordErrors.currentPassword}
              </Form.Control.Feedback>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Новый пароль</Form.Label>
              <Form.Control
                type="password"
                value={passwordData.newPassword}
                onChange={(e) =>
                  setPasswordData({
                    ...passwordData,
                    newPassword: e.target.value,
                  })
                }
                isInvalid={!!passwordErrors.newPassword}
              />
              <Form.Text className="text-muted">
                Минимум 8 символов, 1 цифра и 1 заглавная буква
              </Form.Text>
              <Form.Control.Feedback type="invalid">
                {passwordErrors.newPassword}
              </Form.Control.Feedback>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Подтвердите новый пароль</Form.Label>
              <Form.Control
                type="password"
                value={passwordData.confirmNewPassword}
                onChange={(e) =>
                  setPasswordData({
                    ...passwordData,
                    confirmNewPassword: e.target.value,
                  })
                }
                isInvalid={!!passwordErrors.confirmNewPassword}
              />
              <Form.Control.Feedback type="invalid">
                {passwordErrors.confirmNewPassword}
              </Form.Control.Feedback>
            </Form.Group>
            <Button
              variant="primary"
              type="submit"
              disabled={isChangingPassword}
              className="w-100"
            >
              {isChangingPassword ? "Изменение..." : "Изменить пароль"}
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
      {showVerificationForm && (
        <div className={styles.verificationOverlay}>
          <div className={styles.verificationCard}>
            <div className={styles.verificationHeader}>
              <FaEnvelope />
              <h3>Подтвердите ваш email</h3>
            </div>
            <input
              type="text"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value)}
              placeholder="Введите код из письма"
            />
            <Button onClick={handleVerifyEmail} disabled={isVerifying}>
              {isVerifying ? "Проверка..." : "Подтвердить"}
            </Button>
            <Button variant="link" onClick={handleResendCode}>
              Отправить код повторно
            </Button>
            {verificationMessage && (
              <p className="text-success">{verificationMessage}</p>
            )}
            {verificationError && (
              <p className="text-danger">{verificationError}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileSection;