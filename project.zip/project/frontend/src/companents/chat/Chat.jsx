import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { io } from 'socket.io-client';
import '../../assets/style/chat/Chat.css';

const Chat = ({ orderId, userId }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [previewImages, setPreviewImages] = useState([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [loading, setLoading] = useState(true);
  const fileInputRef = useRef(null);
  const socketRef = useRef(null);
  const chatContainerRef = useRef(null);

  // Функция для подключения к сокету
  const connectSocket = () => {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('No token found in localStorage');
      return;
    }

    // Отключаем предыдущее соединение, если оно есть
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }

    // Создаем новое подключение с правильными параметрами
    socketRef.current = io('http://localhost:5000', {
      auth: {
        token: token
      },
      query: {
        token: token
      },
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      timeout: 10000,
    });

    // Обработчики событий
    socketRef.current.on('connect', () => {
      console.log('Successfully connected to socket server');
      socketRef.current.emit('joinRoom', orderId);
    });

    socketRef.current.on('connect_error', (err) => {
      console.error('Socket connection error:', err.message);
      toast.error(`Ошибка подключения к чату: ${err.message}`);
    });

    socketRef.current.on('message', (message) => {
      console.log('New message received:', message);
      setMessages(prev => [...prev, message]);
      scrollToBottom();
    });

    socketRef.current.on('disconnect', (reason) => {
      console.log('Disconnected from socket server. Reason:', reason);
      if (reason === 'io server disconnect') {
        // Переподключаемся через 1 секунду
        setTimeout(connectSocket, 1000);
      }
    });

    socketRef.current.on('error', (error) => {
      console.error('Socket error:', error);
    });
  };

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`http://localhost:5000/api/orders/${orderId}/messages`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      setMessages(response.data.data || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast.error('Не удалось загрузить сообщения');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));

    if (files.length !== imageFiles.length) {
      toast.warning('Можно загружать только изображения');
      return;
    }

    if (files.length > 5) {
      toast.warning('Можно загружать не более 5 файлов за раз');
      return;
    }

    setAttachments(files);

    // Создаем превью для изображений
    const previews = files.map(file => ({
      name: file.name,
      url: URL.createObjectURL(file),
      size: file.size
    }));
    setPreviewImages(previews);
  };

  const removeAttachment = (index) => {
    const newAttachments = [...attachments];
    newAttachments.splice(index, 1);
    setAttachments(newAttachments);

    const newPreviews = [...previewImages];
    URL.revokeObjectURL(newPreviews[index].url);
    newPreviews.splice(index, 1);
    setPreviewImages(newPreviews);
  };

  const handleSendMessage = async () => {
    if ((!newMessage.trim() && attachments.length === 0) || !socketRef.current) return;

    try {
      setIsUploading(true);
      const formData = new FormData();
      formData.append('content', newMessage);

      attachments.forEach(file => {
        formData.append('attachments', file);
      });

      const response = await axios.post(
        `http://localhost:5000/api/orders/${orderId}/messages`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'multipart/form-data'
          },
          onUploadProgress: (progressEvent) => {
            const progress = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            setUploadProgress(progress);
          }
        }
      );

      setNewMessage('');
      setAttachments([]);
      setPreviewImages([]);
      setUploadProgress(0);

      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error(error.response?.data?.message || 'Не удалось отправить сообщение');
    } finally {
      setIsUploading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const scrollToBottom = () => {
    chatContainerRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Подключаемся к сокету при монтировании компонента
    connectSocket();
    fetchMessages();

    // Отключаемся при размонтировании
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
      // Очищаем URL объектов для превью
      previewImages.forEach(preview => {
        URL.revokeObjectURL(preview.url);
      });
    };
  }, [orderId]);

const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i]; 
};

return (
  <div className="chat-container">
    {loading ? (
      <div className="loading-state">
        <div className="loading-spinner"></div>
        <p>Загружаем сообщения...</p>
      </div>
    ) : (
      <>
        <div className="message-list">
          {messages.length === 0 ? (
            <div className="empty-state">
              <i className="bi bi-chat-square-text"></i>
              <p>Начните общение — отправьте первое сообщение</p>
            </div>
          ) : (
            messages.map(message => (
              <div key={message._id} className={`message ${message.sender._id === userId ? 'sent' : 'received'}`}>
                <div className="message-sender-avatar">
                  {message.sender.avatar ? (
                    <img 
                      src={message.sender.avatar} 
                      alt={message.sender.firstName} 
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = '/default-avatar.png';
                      }}
                    />
                  ) : (
                    <div className="avatar-placeholder">
                      {message.sender.firstName.charAt(0)}{message.sender.lastName.charAt(0)}
                    </div>
                  )}
                </div>
                <div className="message-content-wrapper">
                  <div className="message-header">
                    <span className="message-sender">{message.sender.firstName} {message.sender.lastName}</span>
                    <span className="message-timestamp">
                      {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  
                  {message.content && (
                    <div className="message-content">
                      {message.content}
                    </div>
                  )}
                  
                  {message.attachments && message.attachments.length > 0 && (
                    <div className="message-attachments">
                      {message.attachments.map((attachment, index) => (
                        <div key={index} className="attachment">
                          {attachment.type === 'image' ? (
                            <a href={attachment.url} target="_blank" rel="noopener noreferrer" className="image-attachment">
                              <img
                                src={attachment.url}
                                alt={`Вложение ${index + 1}`}
                                className="attachment-image"
                                onError={(e) => {
                                  e.target.onerror = null;
                                  e.target.src = '/image-error.png';
                                }}
                              />
                            </a>
                          ) : (
                            <a 
                              href={attachment.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="file-attachment-link"
                            >
                              <div className="file-attachment">
                                <div className="file-icon">
                                  <i className="bi bi-file-earmark-text"></i>
                                </div>
                                <div className="file-info">
                                  <span className="file-name">{attachment.filename}</span>
                                  <span className="file-size">{formatFileSize(attachment.size)}</span>
                                </div>
                              </div>
                            </a>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          <div ref={chatContainerRef} />
        </div>

        {/* Превью загружаемых изображений */}
        {previewImages.length > 0 && (
          <div className="preview-images">
            <div className="preview-header">
              <span>Готово к отправке ({previewImages.length})</span>
              <button 
                className="clear-all-btn"
                onClick={() => {
                  previewImages.forEach(preview => URL.revokeObjectURL(preview.url));
                  setPreviewImages([]);
                  setAttachments([]);
                }}
              >
                Очистить все
              </button>
            </div>
            <div className="preview-grid">
              {previewImages.map((preview, index) => (
                <div key={index} className="preview-item">
                  <div className="preview-image-container">
                    <img
                      src={preview.url}
                      alt={`Превью ${preview.name}`}
                      className="preview-image"
                    />
                    <div className="preview-overlay">
                      <span className="preview-name">{preview.name}</span>
                    </div>
                  </div>
                  <button
                    className="remove-btn"
                    onClick={() => removeAttachment(index)}
                    title="Удалить"
                  >
                    <i className="bi bi-x-lg"></i>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Индикатор загрузки */}
        {isUploading && (
          <div className="upload-progress">
            <div className="progress-text">
              Отправка {uploadProgress}%
            </div>
            <div className="progress-track">
              <div
                className="progress-bar"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
          </div>
        )}

        <div className="input-area">
          <button
            className="btn attachment-btn"
            onClick={() => fileInputRef.current.click()}
            title="Прикрепить изображение"
            disabled={isUploading}
          >
            <i className="bi bi-plus-lg"></i>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            multiple
            accept="image/*"
            style={{ display: 'none' }}
            disabled={isUploading}
          />
          
          <div className="message-input-container">
            <textarea
              placeholder="Напишите сообщение..."
              value={newMessage}
              onChange={e => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              rows={1}
              disabled={isUploading}
            />
            <button
              onClick={handleSendMessage}
              disabled={(!newMessage.trim() && attachments.length === 0) || isUploading}
              className="send-btn"
            >
              {isUploading ? (
                <div className="send-spinner"></div>
              ) : (
                <i className="bi bi-send-fill"></i>
              )}
            </button>
          </div>
        </div>
      </>
    )}
  </div>
);
};

export default Chat;