import React, { useState, useEffect } from 'react';
import { Bar, Pie } from 'react-chartjs-2';
import { adminOrdersApi } from '../../api/admin/order';
import { Card, Spinner, Tabs, Tab, Alert, Row, Col } from 'react-bootstrap';
import 'chart.js/auto';
import '../../assets/style/admin/adminStyles.css';


const Stats = () => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [activeTab, setActiveTab] = useState('daily');

    const formatMoney = (amount) => {
        return new Intl.NumberFormat('ru-RU', {
            style: 'currency',
            currency: 'RUB',
            minimumFractionDigits: 0,
        }).format(amount);
    };

    useEffect(() => {
        const fetchStats = async () => {
            try {
                setLoading(true);
                const response = await adminOrdersApi.getStats();
                setStats(response.data);
                setError(null);
            } catch (err) {
                setError(err.message || 'Ошибка загрузки статистики');
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    if (loading) {
        return (
            <div className="d-flex justify-content-center align-items-center loading-container">
                <Spinner animation="border" variant="primary" />
            </div>
        );
    }

    if (error) {
        return (
            <Alert variant="danger" className="mt-4">
                {error}
            </Alert>
        );
    }

    if (!stats) {
        return null;
    }

    // Функция для форматирования даты в "день.месяц.год"
    const formatDate = (dateString) => {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Месяцы начинаются с 0
        const year = date.getFullYear();
        return `${day}.${month}.${year}`;
    };

    // Подготовка данных для графиков
    const statusData = {
        labels: stats.statusStats.map((item) => {
            const statusMap = {
                active: 'Активные',
                in_progress: 'В работе',
                completed: 'Завершенные',
                canceled: 'Отмененные',
                pending_completion: 'Ожидают подтверждения',
            };
            return statusMap[item._id] || item._id;
        }),
        datasets: [
            {
                data: stats.statusStats.map((item) => item.count),
                backgroundColor: ['#28a745', '#dc3545', '#ffc107', '#17a2b8', '#007bff'], // Boostrap color palette, for example
                hoverBackgroundColor: ['#218838', '#c82333', '#e0a800', '#138496', '#0069d9'],
                hoverBorderColor: 'rgba(255, 255, 255, 1)',
            },
        ],
    };

    const dailyData = {
        labels: stats.dailyStats.map((item) => formatDate(item._id)), // Используем функцию formatDate
        datasets: [
            {
                label: 'Заказов создано',
                backgroundColor: '#007bff',
                hoverBackgroundColor: '#0069d9',
                borderColor: '#007bff',
                data: stats.dailyStats.map((item) => item.count),
            },
        ],
    };

    const options = {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'bottom', // Более современный вид
            },
            tooltip: {
                backgroundColor: 'rgb(255,255,255)',
                bodyColor: '#858796',
                borderColor: '#dddfeb',
                borderWidth: 1,
                padding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    title: (context) => {
                        const title = context[0].label;
                        return title; // Formatted date is already in the label
                    },
                },
            },
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    precision: 0,
                },
                grid: {
                    color: 'rgba(0, 0, 0, 0.05)', // Light gray gridlines
                },
            },
            x: {
                 grid: {
                    color: 'rgba(0, 0, 0, 0.05)', // Light gray gridlines
                },
            }
        },
    };
    const completedStats = stats.completedStats || {};

    return (
        <div className="admin-stats container-fluid">
            <h2 className="page-title mb-4">Статистика заказов</h2>
            <Row className="mb-4">
                <Col xl={4} lg={6} md={12}>
                    <Card className="stat-card shadow">
                        <Card.Body>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 className="stat-title">Всего завершено заказов</h6>
                                    <h3 className="stat-value">{completedStats.totalCompleted || 0}</h3>
                                </div>
                                <div className="stat-icon icon-success">
                                    <i className="bi bi-check-circle-fill"></i>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>

                <Col xl={4} lg={6} md={12}>
                    <Card className="stat-card shadow">
                        <Card.Body>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 className="stat-title">Общая сумма выполненных</h6>
                                    <h3 className="stat-value">{formatMoney(completedStats.totalRevenue || 0)}</h3>
                                </div>
                                <div className="stat-icon icon-primary">
                                    <i className="bi bi-cash-stack"></i>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>

                <Col xl={4} lg={6} md={12}>
                    <Card className="stat-card shadow">
                        <Card.Body>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 className="stat-title">Средняя стоимость заказа</h6>
                                    <h3 className="stat-value">{formatMoney(completedStats.avgPrice || 0)}</h3>
                                </div>
                                <div className="stat-icon icon-info">
                                    <i className="bi bi-graph-up"></i>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="mb-4">
                <Col xl={6} lg={6}>
                    <Card className="chart-card shadow">
                        <Card.Body>
                            <h5 className="chart-title">Распределение по статусам</h5>
                            <div className="chart-container">
                                <Pie
                                    data={statusData}
                                    options={{
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: true,
                                                position: 'bottom',
                                            },
                                            tooltip: {
                                                callbacks: {
                                                    label: (context) => {
                                                        const label = context.label || '';
                                                        const value = context.raw || 0;
                                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                                        const percentage = Math.round((value / total) * 100);
                                                        return `${label}: ${value} (${percentage}%)`;
                                                    },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>

                <Col xl={6} lg={6}>
                    <Card className="chart-card shadow">
                        <Card.Body>
                            <h5 className="chart-title">Финансовая статистика по статусам</h5>
                            <div className="chart-container">
                                <Bar
                                    data={{
                                        labels: statusData.labels,
                                        datasets: [
                                            {
                                                label: 'Сумма заказов',
                                                data: stats.statusStats.map((item) => item.totalPrice),
                                                backgroundColor: '#17a2b8',
                                                hoverBackgroundColor: '#138496',
                                                borderColor: '#17a2b8',
                                            },
                                        ],
                                    }}
                                    options={{
                                        ...options,
                                        plugins: {
                                            ...options.plugins,
                                            tooltip: {
                                                ...options.plugins.tooltip,
                                                callbacks: {
                                                    label: (context) => {
                                                        const label = context.dataset.label || '';
                                                        const value = context.raw || 0;
                                                        return `${label}: ${formatMoney(value)}`;
                                                    },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Card className="shadow mb-4">
                <Card.Body>
                    <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k)} className="custom-tabs">
                        <Tab eventKey="daily" title="По дням">
                            <div className="chart-area">
                                <Bar data={dailyData} options={options} />
                            </div>
                        </Tab>
                        <Tab eventKey="status" title="По статусам">
                            <div className="chart-container">
                                <Pie
                                    data={statusData}
                                    options={{
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: true,
                                                position: 'bottom',
                                            },
                                        },
                                    }}
                                />
                            </div>
                        </Tab>
                    </Tabs>
                </Card.Body>
            </Card>
        </div>
    );
};

export default Stats;
