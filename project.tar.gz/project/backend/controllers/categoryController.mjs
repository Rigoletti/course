import Category from "../models/Category.mjs";
import Order from "../models/Order.mjs";
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from '../config/multerConfig.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const uploadIcon = multer.single('icon');

export const getCategories = async (req, res) => {
    try {
        const categories = await Category.find().lean();
        const allOrders = await Order.find({}, 'category skills').lean();
        
        const categoriesWithOrders = categories.map(category => {
            const categoryOrders = allOrders.filter(order => 
                order.category && order.category.toString() === category._id.toString()
            );
            
            // Считаем количество заказов для каждого навыка
            const skillCounts = {};
            categoryOrders.forEach(order => {
                order.skills?.forEach(skill => {
                    skillCounts[skill] = (skillCounts[skill] || 0) + 1;
                });
            });
            
            // Преобразуем в массив объектов
            const skillCountsArray = Object.entries(skillCounts).map(([name, orders]) => ({
                name,
                orders
            }));
            
            return {
                ...category,
                skillCounts: skillCountsArray
            };
        });
        
        res.status(200).json(categoriesWithOrders);
    } catch (error) {
        console.error('Error in getCategories:', error);
        res.status(500).json({ 
            success: false,
            message: 'Ошибка при получении категорий',
            error: error.message 
        });
    }
};

export const createCategory = async (req, res) => {
    try {
        const { title, services = [] } = req.body;

        if (!title) {
            return res.status(400).json({ 
                success: false,
                message: 'Название категории обязательно'
            });
        }

        const link = `/category/${title.toLowerCase().replace(/\s+/g, '-')}`;

        const newCategory = new Category({
            title,
            link,
            services,
            skillCounts: services.map(service => ({
                name: service,
                orders: 0
            }))
        });

        await newCategory.save();
        res.status(201).json({
            success: true,
            data: newCategory
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: 'Ошибка при создании категории',
            error: error.message
        });
    }
};

export const getCategoryById = async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ 
                success: false,
                message: "Категория не найдена" 
            });
        }
        
        // Получаем количество заказов для каждого навыка
        const ordersCount = await Order.aggregate([
            { $match: { category: category._id } },
            { $unwind: "$skills" },
            { $group: { 
                _id: "$skills", 
                count: { $sum: 1 } 
            }},
            { $project: {
                name: "$_id",
                orders: "$count",
                _id: 0
            }}
        ]);
        
        const categoryWithOrders = {
            ...category.toObject(),
            skillCounts: ordersCount
        };
        
        res.status(200).json({
            success: true,
            data: categoryWithOrders
        });
    } catch (error) {
        res.status(500).json({ 
            success: false,
            message: 'Ошибка при получении категории',
            error: error.message 
        });
    }
};

export const updateCategory = async (req, res) => {
    try {
      const { title, link, services = [] } = req.body;
      
      if (!title || !link) {
        return res.status(400).json({
          success: false,
          message: 'Название и ссылка категории обязательны',
          receivedData: req.body
        });
      }
  
      const category = await Category.findById(req.params.id);
      if (!category) {
        return res.status(404).json({ 
          success: false,
          message: "Категория не найдена" 
        });
      }
  
      // Сохраняем текущие счетчики заказов
      const existingCounts = {};
      category.skillCounts.forEach(skill => {
        existingCounts[skill.name] = skill.orders;
      });
  
      // Обновляем данные
      category.title = title;
      category.link = link;
      category.services = services;
      
      // Обновляем счетчики навыков, сохраняя счетчики
      category.skillCounts = services.map(service => ({
        name: service,
        orders: existingCounts[service] || 0
      }));
  
      category.updatedAt = Date.now();
      await category.save();
      
      res.status(200).json({
        success: true,
        data: category
      });
    } catch (error) {
      console.error('Update category error:', error);
      res.status(400).json({ 
        success: false,
        message: 'Ошибка при обновлении категории',
        error: error.message 
      });
    }
};

export const deleteCategory = async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ 
                success: false,
                message: "Категория не найдена" 
            });
        }

        await Order.deleteMany({ category: req.params.id });
        
        if (category.icon) {
            try {
                fs.unlinkSync(path.join(__dirname, '../uploads', category.icon));
            } catch (err) {
                console.error('Ошибка при удалении иконки:', err);
            }
        }
        
        await Category.findByIdAndDelete(req.params.id);
        
        res.status(200).json({ 
            success: true,
            message: "Категория и связанные заказы успешно удалены" 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false,
            message: 'Ошибка при удалении категории',
            error: error.message 
        });
    }
};

export const updateSkillOrders = async (req, res) => {
    const { categoryId, skillName } = req.params;

    try {
        const category = await Category.findById(categoryId);
        if (!category) {
            return res.status(404).json({ 
                success: false,
                message: "Категория не найдена" 
            });
        }

        const skill = category.skillCounts.find(s => s.name === skillName);
        if (!skill) {
            return res.status(404).json({ 
                success: false,
                message: "Навык не найден" 
            });
        }

        skill.orders += 1;
        await category.save();

        res.status(200).json({
            success: true,
            data: category
        });
    } catch (error) {
        res.status(500).json({ 
            success: false,
            message: 'Ошибка при обновлении счетчика заказов',
            error: error.message 
        });
    }
};

export const getCategoryStats = async (req, res) => {
    try {
        const categoryId = req.params.id;
        
        const totalOrders = await Order.countDocuments({ category: categoryId });
        
        const category = await Category.findById(categoryId);
        if (!category) {
            return res.status(404).json({ 
                success: false,
                message: "Категория не найдена" 
            });
        }
        
        const skillStats = await Order.aggregate([
            { $match: { category: category._id } },
            { $unwind: "$skills" },
            { $group: { 
                _id: "$skills", 
                count: { $sum: 1 } 
            }},
            { $project: {
                name: "$_id",
                orders: "$count",
                _id: 0
            }}
        ]);
        
        res.status(200).json({
            success: true,
            data: {
                totalOrders,
                skills: skillStats
            }
        });
    } catch (error) {
        res.status(500).json({ 
            success: false,
            message: 'Ошибка при получении статистики',
            error: error.message 
        });
    }
};