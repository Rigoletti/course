import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import { useFormik } from "formik";
import { FaCheck, FaGithub } from "react-icons/fa";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { profileSchema } from "../../utils/validation";
import "../../assets/style/auth/CompleteGithubRegistration.css";

const CompleteGithubRegistration = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  const queryParams = new URLSearchParams(location.search);
  const token = queryParams.get("token");

  useEffect(() => {
    if (!token) {
      toast.error("Отсутствует токен авторизации");
      navigate("/authorization");
    }
  }, [token, navigate]);

  const formik = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      email: "",
    },
    validationSchema: profileSchema,
    onSubmit: async (values) => {
      setIsSubmitting(true);
      try {
        const response = await axios.post(
          "http://localhost:5000/api/auth/complete-github-registration",
          values,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        localStorage.setItem("token", response.data.token);
        toast.success("Регистрация завершена! Перенаправляем...");
        
        setTimeout(() => {
          window.location.href = "/profile";
        }, 1500);
        
      } catch (error) {
        console.error("Ошибка регистрации:", error);
        toast.error(error.response?.data?.message || "Ошибка при завершении регистрации");
      } finally {
        setIsSubmitting(false);
      }
    },
  });

  return (
    <div className="github-registration-container">
      <ToastContainer 
        position="top-center"
        autoClose={3000}
        theme="colored"
        toastClassName="custom-toast"
        progressClassName="custom-toast-progress"
      />
      
      <div className="github-registration-card">
        <div className="github-brand-header">
          <FaGithub className="github-icon" size={28} />
          <h2>Завершение регистрации</h2>
          <p className="subtitle">Пожалуйста, заполните недостающие данные</p>
        </div>
        
        <form onSubmit={formik.handleSubmit} className="github-registration-form">
          <div className="form-group">
            <label htmlFor="firstName">Имя</label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              className={`form-input ${formik.touched.firstName && formik.errors.firstName ? 'error' : ''}`}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.firstName}
              placeholder="Введите ваше имя"
            />
            {formik.touched.firstName && formik.errors.firstName && (
              <div className="error-message">{formik.errors.firstName}</div>
            )}
          </div>
          
          <div className="form-group">
            <label htmlFor="lastName">Фамилия</label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              className={`form-input ${formik.touched.lastName && formik.errors.lastName ? 'error' : ''}`}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.lastName}
              placeholder="Введите вашу фамилию"
            />
            {formik.touched.lastName && formik.errors.lastName && (
              <div className="error-message">{formik.errors.lastName}</div>
            )}
          </div>
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              className={`form-input ${formik.touched.email && formik.errors.email ? 'error' : ''}`}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.email}
              placeholder="Введите ваш email"
            />
            {formik.touched.email && formik.errors.email && (
              <div className="error-message">{formik.errors.email}</div>
            )}
          </div>
          
          <button 
            type="submit" 
            className="submit-button"
            disabled={isSubmitting || !formik.isValid}
          >
            {isSubmitting ? (
              <span className="button-loader"></span>
            ) : (
              <>
                <FaCheck className="button-icon" />
                Завершить регистрацию
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CompleteGithubRegistration;