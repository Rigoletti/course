import React, { useState } from 'react';
import { Modal, Form, Button } from 'react-bootstrap';

const ProposalModal = ({ show, onHide, onSubmit, orderPrice }) => {
  const [message, setMessage] = useState('');
  const [price, setPrice] = useState('');
  const [daysToComplete, setDaysToComplete] = useState('');
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    
    if (!message || message.length < 10) {
      newErrors.message = 'Сообщение должно содержать не менее 10 символов';
    }
    
    if (price && isNaN(price)) {
      newErrors.price = 'Цена должна быть числом';
    }
    
    if (daysToComplete && isNaN(daysToComplete)) {
      newErrors.daysToComplete = 'Срок должен быть числом';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validate()) {
      onSubmit({
        message,
        price: price ? Number(price) : undefined,
        daysToComplete: daysToComplete ? Number(daysToComplete) : undefined
      });
    }
  };

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>Отправить предложение</Modal.Title>
      </Modal.Header>
      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          <Form.Group className="mb-3">
            <Form.Label>Ваше предложение *</Form.Label>
            <Form.Control
              as="textarea"
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              isInvalid={!!errors.message}
              placeholder="Опишите ваше предложение, почему вы подходите для этого заказа и т.д."
              required
            />
            <Form.Control.Feedback type="invalid">
              {errors.message}
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Предложенная цена (₽)</Form.Label>
            <Form.Control
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              isInvalid={!!errors.price}
              placeholder={`Примерная цена заказа: ${orderPrice}₽`}
            />
            <Form.Control.Feedback type="invalid">
              {errors.price}
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Срок выполнения (дней)</Form.Label>
            <Form.Control
              type="number"
              value={daysToComplete}
              onChange={(e) => setDaysToComplete(e.target.value)}
              isInvalid={!!errors.daysToComplete}
              placeholder="Укажите, за сколько дней вы выполните заказ"
            />
            <Form.Control.Feedback type="invalid">
              {errors.daysToComplete}
            </Form.Control.Feedback>
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={onHide}>
            Отмена
          </Button>
          <Button variant="primary" type="submit">
            Отправить предложение
          </Button>
        </Modal.Footer>
      </Form>
    </Modal>
  );
};

export default ProposalModal;