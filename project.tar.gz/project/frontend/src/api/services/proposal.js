import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export const createProposal = async (orderId, proposalData) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Требуется авторизация');
    }

    const response = await axios.post(
      `${API_BASE_URL}/orders/${orderId}/proposals`,
      proposalData,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data;
  } catch (error) {
    console.error('Error creating proposal:', error);
    throw new Error(error.response?.data?.message || 'Ошибка при создании предложения');
  }
};

export const getOrderProposals = async (orderId) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Требуется авторизация');
    }

    const response = await axios.get(
      `${API_BASE_URL}/orders/${orderId}/proposals`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    return response.data;
  } catch (error) {
    console.error('Error getting order proposals:', error);
    throw new Error(error.response?.data?.message || 'Ошибка при получении предложений');
  }
};

export const getUserProposals = async () => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Требуется авторизация');
    }

    const response = await axios.get(
      `${API_BASE_URL}/users/proposals`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    return response.data;
  } catch (error) {
    console.error('Error getting user proposals:', error);
    throw new Error(error.response?.data?.message || 'Ошибка при получении ваших предложений');
  }
};

export const updateProposalStatus = async (proposalId, status) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Требуется авторизация');
    }

    const response = await axios.put(
      `${API_BASE_URL}/proposals/${proposalId}/status`,
      { status },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data;
  } catch (error) {
    console.error('Error updating proposal status:', error);
    throw new Error(error.response?.data?.message || 'Ошибка при обновлении статуса предложения');
  }
};