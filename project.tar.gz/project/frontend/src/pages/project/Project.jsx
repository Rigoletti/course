import React from "react";
import PostProject from "../../companents/post_project/PostProject";
import Header from "../../companents/layout/Header";

const Project=()=>{
    return(
        <div>
            <Header />
            <PostProject />
        </div>
    )
}

export default Project;