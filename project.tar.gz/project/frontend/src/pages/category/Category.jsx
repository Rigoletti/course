import React from "react";
import CategorySection from "../../companents/category/CategorySection";
import Header from "../../companents/layout/Header";

const Executor=()=>{
    return(
        <div>
   <Header />
   <CategorySection />
        </div>
     
    )
}


export default Executor;